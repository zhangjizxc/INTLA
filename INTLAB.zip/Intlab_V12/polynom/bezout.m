function B = bezout(p,q)
%BEZOUT       Bezout matrix
%
%   B = bezout(p,q)
%
%Here p and q are vectors of lengths m and n, respectively, interpreted as
%polynomials with leading coefficients p1 and q1.
%

% written  08/25/18     S.M. Rump  
%

  np = length(p) - 1;
  nq = length(q) - 1;
  n = max(np,nq);
  p = p(:).';
  q = q(:).';
  A = toeplitz([p(np+1) zeros(1,n-1)],[fliplr(p) zeros(1,2*n-np-1)]);
  B = toeplitz([q(nq+1) zeros(1,n-1)],[fliplr(q) zeros(1,2*n-nq-1)]);
  B = flipud( A(:,n+1:end)*B(:,1:n) - B(:,n+1:end)*A(:,1:n) );
end  % function bezout
