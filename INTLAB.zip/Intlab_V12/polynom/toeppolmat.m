function T = toeppolmat(p,k)
%TOEPPOLMAT   Toeplitz polynomial matrix
%
%   T = toeppolmat(p,k)
%
%For a univariate polynomial p, T is the Toeplitz polynomial matrix with k columns. 
%Thus for polynomials p,q of degree m,n, T(p,n+1)*q = T(q,m+1)*p is the
%convolution of p and q.
%

% written  08/25/18     S.M. Rump  
% modified 01/19/20     S.M. Rump  complex input not transposed by toeplitz
%
  if isa(p,'polynom')
    if numvars(p)>1
      error('toeppolmat only for univariate polynomials')
    end
    p = coeffs(p);
  end
  
  c = [p(:);zeros(k-1,1)];
  T = tril(toeplitz(c,c.'));
  T = T(:,1:k);
  
end  % function toeppolmat
