function r = rdivide(p,q)
%RDIVIDE      Implements  p ./ q  for univariate polynomials (same as p/q)
%

% written  11/02/05     S.M. Rump
%

  r = p / q;
  