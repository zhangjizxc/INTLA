function n = numels(a)
%NUMELS       Overloaded functions, necessary for Matlab V6.1f
%

% written  10/03/02     S.M. Rump
% modified 01/14/20     S.M. Rump  redesign numel and numels
%

  n = numels(a.c);
  
end  % function numels
