function b = bernsteincoeff(p,domain)
%BERNSTEINCOEFF    Bernstein coefficients for polynomial p over [0,1]
%
%For upward compatibility: 
%functionality as of the fast function polynom/bersteincoeff by Titi and Garloff:
%   [TG] J. Titi, J. Garloff, Matrix methods for the tensorial Bernstein form, 
%          Applied Mathematics and Computation 346, p.254-271, 2019
%but output is of type polynom. 
%
%For p denoting a polynomial of degree n and B(n,i) denoting the i-th Bernstein 
%polynomial of degree n it is
%
%  p = sum( i=0:n , b(i)*B(n,i)(x) ) .
%
%For convenience, the result b is a polynomial, so that b(i) denotes the i-th Bernstein
%coefficient for i=0:n. Note, however, that the coefficients b(i) are with
%respect to the Bernstein basis.
%
%Note that the convex hull of all ( x , p(x) ) for x in [0,1] is contained in the
%convex hull of { ( i/n , b(i) ) : 0<=i<=n } .
%Especially, b(0)=p(0), b(1)=p(1) and the infsup(min(b.c),max(b.c)) contains the range 
%of p over [0,1].
%
%To compute Bernstein coefficients with respect to another interval [a,b] use
%  b = bernsteincoeff(p,domain)
%Here domain is an optional parameter. If specified, it must be an interval vector 
%of length n, where domain(i) is the domain interval for variable x_i, i = 1,...,n. 
%If "domain" is empty or not specified, then the standard domain [0,1]^n is taken. 
%

% written  10/25/02     S.M. Rump
% modified 04/04/04     S.M. Rump  set round to nearest for safety
% modified 04/06/05     S.M. Rump  rounding unchanged
% modified 09/28/08     S.M. Rump  check for rounding to nearest improved
% modified 07/30/16     S.M. Rump  rounding check by getround for Matlab 2016b 
% modified 01/19/20     S.M. Rump  redesign based on fast polynom/bernsteincoeff
%

  if nargin==2
    [bs,I] = bernsteincoeff(struct(p),domain);
    b = polynom(bs,I,p.v);
  else
    [bs,I] = bernsteincoeff(struct(p));
    b = polynom(bs,I,p.v);
  end

end  % function @polynom\bernsteincoeff
