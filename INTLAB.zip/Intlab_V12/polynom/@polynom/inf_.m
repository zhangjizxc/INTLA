function r = inf_(a)
%INF_         Implements  inf(a)  (cures problems with inf)
%
%   c = inf_(a)
%
% On return, inf(a) <= alpha for all entries alpha in a
%
%************************************************************************
%********  due to conflict with internal variable inf (infinity)  *******
%********                    use function inf_                    *******
%************************************************************************
%

% Implementation for point arguments
%

% written  07/29/18     S.M. Rump
%

  r = inf(a);
