function plotbernstein(B,a,b)
%PLOTBERNSTEIN  Plots Berstein points with connecting lines
%
%For univariate Bernstein points, 
%
%   plotbernstein(B)
%
%plots Bernstein points in default interval [0,1]. Correspondingly, 
%
%   plotbernstein(B,a,b)
%
%plots Bernstein points in the interval [a,b]. 
%
%Note that B is the vector of Bernstein coefficients, see bernsteincoeff.
%
%For given polynomial P and an interval [a,b], a typical call for plotting P together with 
%its Bernstein points is
%
%   B = bernsteincoeff(P,infsup(a,b))
%   plotpoly(P,a,b), hold on, plotbernstein(B,a,b), hold off
%
%For completeness and upward compatibility: functionality identical to
%  @polynom\plotbernstein, but here input struct(polynom)
%

% written  12/25/02     S.M. Rump
% modified 04/04/04     S.M. Rump  set round to nearest for safety
% modified 04/06/05     S.M. Rump  rounding unchanged
% modified 11/20/05     S.M. Rump  faster check for rounding to nearest
% modified 07/30/16     S.M. Rump  rounding check by getround for Matlab 2016b 
% modified 05/03/19     S.M. Rump  hold state corrected: checking opens windows
%

  rndold = getround;
  if rndold
    setround(0)
  end

  if ~isreal(B)
    error('polynomial must be real (point or interval)')
  end
  
  if numels(a)*numels(b)==1          % univariate polynomial
    
    if nargin==1
      a = 0;
      b = 1;
    end
    n = length(B);
    X = linspace(a,b,n);
    
    if isa(B,'intval')
      
      Bc = fliplr([B.inf' B.sup']);
      XX = [X X];
      if n>1
        index = convhull(XX,Bc);
      else
        index = 1:2;
      end
      plot(XX,Bc,'o',XX(index),Bc(index),'-o')
      
    else
      
      Bc = fliplr(B');
      if n>2
        index = convhull(X,Bc);
      else
        index = 1:length(Bc);
      end
      plot(X,Bc,'o',X(index),Bc(index),'-o')
      
    end
    
  else
    error('Bernstein plot only for univariate polynomials.')
  end
  
  setround(rndold)
  
end  % function polynom\plotbernstein
