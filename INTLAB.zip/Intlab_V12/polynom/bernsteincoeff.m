function [b,I,d] = bernsteincoeff(p,domain)
%BERNSTEINCOEFF    Bernstein coefficients of a univariate or multivariate polynomial p(x) = sum c(i).* x.^e(i,:) 
%                    over the standard domain [0,1]^n or over an arbitrary domain.  
%
%   [b,I,d] = bernsteincoeff(p,domain)
%
% The implementation follows
%   [TG] J. Titi, J. Garloff, Matrix methods for the tensorial Bernstein form, 
%          Applied Mathematics and Computation 346, p.254-271, 2019.
% It is much faster than the previous implementation!
%
%   input arguments: 
%     p:        polynomial for which the Bernstein coefficients shall be computed. 
%                 Its coefficients can be floating-point numbers or intervals. 
%                 In the former case non-verfied and in the latter verified computations 
%                 are carried out. 
%     domain:   This is an optional parameter. If specified, it must be an interval 
%                 vector of length n, where domain(i) is the domain interval for 
%                 variable x_i, i = 1,...,n. If "domain" is empty or not specified, 
%                 then the standard domain [0,1]^n is taken. 
%
%   output arguments:
%     b:        Bernstein coefficients. If the input polynomial p(x) has floating-point 
%                 coefficients, then b is a floating-point vector of nonzero Bernstein 
%                 coefficients computed in nonverified floating-point arithmetic. 
%                 Accordingly, if p(x) has interval coefficients, then b is an interval 
%                 vector with nonzero components including all possible non-zero
%                 Bernstein coefficients of p(x). (Due to rounding errors, also 
%                 theoretically zero Bernstein coefficients might be included by 
%                 nonzero intervals.)  
%     I:        indices of Bernstein coefficients corresponding to b
%     d:        degrees of Bernstein basis polynomials. 
%
%     p(x) = sum_k b_{I(k,:)} * B_{I(k,:)}^(d) (x) with Bernstein basis polynomials 
%       B_i^(d) (x) = (d over i) x^i * (1-x)^(d-i), see [TG], p.256, (6)-(9).
%
%

% written  01/24/19     F. Buenger
% modified 01/14/20     S.M. Rump  numel -> numels
%

  c = p.c;                          % polynomial coefficients
  verified = ~isfloat(c);           % verfied computation
  e = p.e;                          % polynomial exponents p(x) = sum c(i).* x.^e(i,:)
  if numels(e) == 1                  % Univariate polynomials are stored as full.
    [~,e,c] = find(fliplr(p.c));    % Convert to sparse notation.
    e = e(:) - 1;                   % exponents
    c = c(:);                       % nonzero coefficients
  end
  [m,n] = size(e);                  % m: number of coefficients c_1,...,c_m; n: number of variables x_1,...,x_n
  if nargin < 2 || isempty(domain)  % optional input argument "domain" is not provided => (implicitly) the standard domain [0,1]^n is taken
    i0 = true(n,1);                 % index for domain components with lower interval bound 0
    i1 = i0;                        % index for domain components with upper interval bound 1
  else
    domain = domain(:);
    if ~isa(domain,'intval') || length(domain.inf) ~= n || any(diam(domain) == 0)  % Point-interval components cannot be transformed to [0,1].
      error('improper domain')
    end
    u = domain.inf;
    v = domain.sup;
    i0 = u == 0;                % index for domain components with lower interval bound 0
    i1 = v == 1;                % index for domain components with upper interval bound 1
    w = u;
    w(i0) = 1;
    if verified
      u = intval(u);            % This will entail overall verified computation.
      v = intval(v);
    end
    w = (v-w)./w;
  end
  
  d = max(e,[],1);              % d(i) is the degree (maximum exponent) for variable x_i, i = 1,...,n.
                                % Remark: in [TG], "d" is denoted by "l". 
                                % Since "l" is too similar to "1" in MATLAB code, we chose "d".
  d_max = max(d);
  max_order = 29;           	% maximum order k up to which the MATLAB built-in function pascal(k) gives an exact result
  
  if d_max > max_order
    error(['The maximum supported order ',num2str(max_order),' is exceeded!'])
  end
  
  persistent nP P D
  if isempty(nP) || nP < d_max+1
    nP = d_max+1;
    P = abs(pascal(nP,1));   	% This is [TG], p.256, Equation (2) [for d_s := m].
    D = pascal(nP);
  end
  
  % Now, the coefficients of the multivariate polynomial p(x) are arranged in a matrix A according to [TG], p.258,259, Equations (21a),(21b),(22).
  
  L = [1,cumprod(d(2:n-1)+1)]';	% L = [1,d2+1,(d2+1)(d3+1),...,(d2+1)*...*(d(n-1)+1)]
  i = e(:,1)+1;              	% The exponents M(:,1) of the first variable x_1 become the row indices of the matrix A (shift "+1" since indexing starts with 1 in MATLAB).
                                % This is [TG], p.258, Equation (21a).
  if n == 1
    j = ones(m,1);
  else
    j = e(:,2:end)*L+1;      	% The column indices of A are computed by "flattening out" the remaining dimensions 2,...,n to one single dimension.
                                % This is [TG], p.258, Equation (21b).
  end
  mA = d(1)+1;
  nA = prod(d(2:n)+1);
  A = sparse(i,j,c,mA,nA);     	% This is [TG], p.259, Equation (22).
  
  B = A;                        % initialization of Bernstein patch B
  for s = 1:n
    d_s = d(s);               	% degree of variable x_s
    P_s = P(1:d_s+1,1:d_s+1); 	% See [TG], p.256, Equation (2).
    % d = binom(d_s,0:d_s);     % This are all binomial coefficients (d_s over i), i = 0,...,d_s, and
                                % 1./d_binom is the diagonal of the matrix D_s_prime of [TG], Remark 4.2, page 261.
    idx = 1:d_s+1;
    d_binom = diag(flipud(D(idx,idx)))';    % same as d_binom = binom(l_s,0:l_s) but faster, see above.
    if i0(s)                                % u(s) = domain.inf(s) == 0
      if i1(s)                              % v(s) = domain.sup(1) == 1 => standard interval [0,1]
        if verified
          P_s = intval(P_s);
          d_binom = intval(d_binom);
        end
        U_s = sparse(P_s./d_binom); 	% U_s = P_s*D_s_prime = P_s*D_s_prime*Q_s, Q_s = identity, see [TG], p.268, Equation (64).
      else
        J = (0:d_s);
        d1 = v(s).^J;                   % See [TG], p.260, Equation (28), Line 2.
        d1 = d1./d_binom;
        U_s = sparse(P_s.*d1);          % U_s = P_s*D_s_prime*Q_s, see [TG], p.268, Equation (64).
      end
    else                                % u(s) = domain.inf(s) ~= 0
      J = (0:d_s);
      d1 = w(s).^J;
      d1 = d1./d_binom;
      d2 = u(s).^J;
      V_s = P_s.*d1;                  	% V_s = P_s*diag(d1)
      W_s = P_s'.*d2;                  	% W_s = P_s'*diag(d_2)
      U_s = sparse(V_s*W_s);          	% U_s = P_s*D_s_prime*Q_s, see [TG], p.268, Equation (64).
    end
    B = U_s * B;
    if s < n
      B = circulate(B,d,s,n);         	% This is [TG], p.268, Equation (65).
    else
      if n == 1
        [i,j,b] = find(B);
        i = i-1;                       	% "index - 1 = exponent"
        j = j-1;
      else
        [B,i,j,b] = circulate(B,d,s,n);
      end
    end
  end
  
  I = zeros(length(i),n);            	% Compute the multiindices I for the Bernstein coefficients b from the row and column indices i,j ...
  I(:,1) = i;                        	% of the Bernstein patch matrix B. This is the inverse operation for the indexing given in [TG], p.258, (21a),(21b).
  for s = 2:n
    d_s = d(s);
    I(:,s) = mod(j,d_s+1);
    j = floor(j/(d_s+1));
  end
  
  b = flipud(b);                        % adapt to INTLAB representation
  I = flipud(I);
  d = flipud(d); 
  
end % function polynom\bernsteincoeff


function [A,row,col,v] = circulate(A,d,s,n)
% This function computes the circular (re)ordering of the matrix A for dimension s according to [TG], p.260, Lines 2,3.
  if s < n
    d_ = d(s+1);
    idx = [1:s-1,s+2:n];
  else
    d_ = d(1);   % There is a minor typo in [TG], p.260, Lines 2,3:
    idx = 2:n-1; % all occurences of "s+1" must be replaced by "(s mod n) + 1".
                 % For s < n this makes no difference, but in case of n = s this
                 % yields "1" instead of "n+1". Note that d(n+1) is undefined as d has length n.
  end
  mA = d_+1;
  if isfloat(A)
    [i,j,v] = find(A);
    v = v(:);
    nA = numels(A)/mA;
  else
%     As = struct(A);
%     if As.complex
%       [i,j,v] = find(A);
%       v = v(:);
%       nA = numels(A.mid)/mA;
%     else
%       [i,j,v] = find(As.inf+1i*As.sup);
%       v_inf = real(v);
%       v_sup = imag(v);
%       v = intval(v_inf(:),v_sup(:),'infsup');
%       nA = numels(As.inf)/mA;
%     end
      [i,j,v] = find(A);
      v = v(:);
      nA = numels(A)/mA;
  end
  i = i-1;                                   % In [TG] indexing starts with 0.
  j = j-1;
  row = mod(j,d_+1);                         % This is [TG], p.260, Line 2.
  col = floor(j/(d_+1)) + i.*prod(d(idx)+1); % This is [TG], p.260, Line 3.
  A = sparse(row+1,col+1,v,mA,nA);           % In MATLAB indexing starts with 1, therefore "row+1" and "col+1".
end % function circulate
