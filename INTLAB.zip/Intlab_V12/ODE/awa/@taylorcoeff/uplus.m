function a = uplus(a)
%UPLUS  Taylor coefficient unary plus  + a
%
%   a = uplus(a) 

% written  08/01/17     F. Buenger

end % function uplus
