function disp(x)
%DISP  display function for pop-up windows in debugger
%

% written  07/31/17     F. Buenger

  display(x,[]);

end % function disp