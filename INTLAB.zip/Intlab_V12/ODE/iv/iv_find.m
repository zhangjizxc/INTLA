function [I,J,V] = iv_find(a)
%IV_FIND         implements  find(a)  for sparse interval interval structures
%
%   I = find(a)
%   [I,J] = find(a)
%   [I,J,V] = find(a)
%
%Functionality as in Matlab.
%

% written  01/30/19     F. Buenger

if nargout<=1
    I = find(abs(a.inf)+abs(a.sup));
elseif nargout==2
    [I,J] = find(abs(a.inf)+abs(a.sup));
elseif nargout==3 
    if numel(a.inf)<2^31
        [I,J] = find(abs(a.inf)+abs(a.sup));
        if isempty(I)                     % Cures Matlab bug.
            K = I;
        elseif isempty(J)                 % Cures Matlab bug.
            K = J;
        else
            K = sub2ind(size(a.inf),I,J);
        end
        V.inf = a.inf(K);
        V.sup = a.sup(K);
    else
        sinf = spones(a.inf(:,:));
        ssup = spones(a.sup(:,:));
        if ~isequal(sinf,ssup)                % Take care of [0,x] and [x,0] components.
            sinfsup = spones(a.inf(:,:)).*spones(a.sup(:,:));
            [I,J] = find(spones(a.inf(:,:))+spones(a.sup(:,:)));
            zinf = ssup-sinfsup;
            zsup = sinf-sinfsup;
            a.inf = a.inf + zinf;             % Set [0,x] components to [1,x].
            a.sup = a.sup + zsup;             % Set [x,0] components to [x,1].
            a.inf = nonzeros(a.inf) + ( 1 - nonzeros(spones(a.inf(:,:))+zinf) );
            a.sup = nonzeros(a.sup) + ( 1 - nonzeros(spones(a.sup(:,:))+zsup) );
            V = a;
        else
            [I,J] = find(sinf);
            V.inf = nonzeros(a.inf);
            V.sup = nonzeros(a.sup);
        end
    end
    V.inf = full(V.inf);    
    V.sup = full(V.sup);    
end

end % function iv_find
