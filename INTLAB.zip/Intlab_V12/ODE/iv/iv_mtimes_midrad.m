function c =  iv_mtimes_midrad(a,b)
%IV_MTIMES_MIDRAD  interval structure matrix multiplication  a * b thru mid/rad arithmetic
%
%   c = iv_mtimes_midrad(a,b)

% written  01/30/19     F. Buenger

e = 1e-30;

if 1+e > 1      % fast check for rounding upwards
    rndold = 1;
else
    rndold = getround;
    setround(1) % rounding upwards 
end

if isfloat(a)
    if isfloat(b) % float * float
        c.sup = a*b;
        c.inf = -((-a)*b);  % equivalent to setround(-1); c.inf = a*b;
    else          % float * interval
        bmid = b.inf + 0.5*(b.sup-b.inf);
        brad = bmid - b.inf;
        crad = abs(a) * brad ;
        c.sup = a*bmid + crad;
        c.inf = -(crad + (-a)*bmid); % equivalent to setround(-1); c.inf = a*bmid - crad;
    end
else
    if isfloat(b) % interval * float
        amid = a.inf + 0.5*(a.sup-a.inf);  % fast interval mtimes interval thru mid/rad arithmetic
        arad = amid - a.inf;
        crad = arad * abs(b);
        c.sup = amid*b + crad;
        c.inf = -(crad + (-amid)*b); % equivalent to setround(-1); c.inf = amid*b - crad;
    else          % iterval * interval
        amid = a.inf + 0.5*(a.sup-a.inf);  % fast interval mtimes interval thru mid/rad arithmetic
        arad = amid - a.inf;
        bmid = b.inf + 0.5*(b.sup-b.inf);
        brad = bmid - b.inf;
        crad = arad * ( abs(bmid) + brad ) + abs(amid) * brad ;
        c.sup = amid*bmid + crad;
        c.inf = -(crad + (-amid)*bmid); % equivalent to setround(-1); c.inf = amid*bmid - crad;
    end
end

if rndold ~= 1 
    setround(rndold)
end

end % function iv_mtimes_midrad
