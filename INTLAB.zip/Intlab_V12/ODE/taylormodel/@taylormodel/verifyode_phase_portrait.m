function verifyode_phase_portrait(T,Y,Yr,y0,t,i1,i2,box,transparency)
% VERIFYODE_PHASE_PORTRAIT  creates a 2d phase plane portrait plot of the result [T,Y,Yr] obtained by verifyode.             
%
%   verifyode_phase_portrait(T,Y,Yr,y0,t,i1,i2,remainder)
%                       
%   It is assumed that [T,Y,Yr] is the output of a call  
%  
%       [T,Y,Yr] = verifyode(odefun,tspan,y0,options)
%
%   for solving an ODE given by the function handle odefun on a time 
%   interval tspan with interval initial value y0 (type intval). 
% 
%   t: Optional parameter. If t is empty (default), then inclusion sets at 
%      all automatically determined time grid points T are plotted, i.e., 
%      t := T is taken. If t is not empty, then inclusion sets and 
%      diameters at all time points t(k) are plotted. It is assumed that 
%      t is sorted in ascending order. Only entries of t that are contained 
%      in the integration interval [T(1),T(end)] are considered.
%
%   i1,i2: Plot solution component y_i1 (x-axis) against solution component 
%          y_i2 (y-axis).  
%
%   box:   0: no interval enclosure boxes are plotted (default)
%          1: verified interval enclosure boxes are plotted around the   
%             the (nonverified) curvy enclosure sets. 
%
%   transparency: value for MATLAB's plot transparency function "alpha".
%                 Specify the value as a scalar value between 0 (transparent) 
%                 and 1 (no transparency), 'clear', or 'opaque'.
%                 Since the function "alpha" is not yet implemented in Octave,
%                 this input argument is ignored under Octave.
%
%   REMARK 1: The curvy enclosure sets are nonverified, meaning that their
%             bounderies of the plotted discretized and simply linearly 
%             connected and that they are not rendered by remainder boxes.
%             The curvy enclosure sets shall only give a good qualitative 
%             visualization of the ODE flow. 
%             Set the flag "box" to plot verified interval enclosure boxes
%             around the nonverified curvy enclosure sets or 
%             use the function verifyode_disp for computing 
%             overall verified enclosures at specific time points. 
%
%   REMARK 2: Due to complexity, use this function only for small 
%             dimensions n, say n <= 7.   

% written  10/15/19     F. Buenger
% modified 01/23/20     F. Buenger  respecting results from integration in negative direction
% modified 02/19/20     F. Buenger  alpha(transparancy) excluded for Octave
  
global INTLAB_CONST

n = length(y0); % length of initial conditions = dimension of ODE system.
if n < 2
    error('Portrait plots are only possible for ODE systems of dimension >= 2.')
end
if nargin < 8 || isempty(box) 
    box = false;
end
if nargin < 7 || isempty(i2) % If i1, i2 are not provided, take default values i1:=1 and i2:=2.
    i1 = 1; 
    i2 = 2;
end

direction = sign(T(end)-T(1)); % direction of integration, 1: positive direction, -1: negative direction 
                               % "direction" is distinct from zero because t0 == tf is excluded by verifyode.
T = direction * T;

if nargin < 5 || isempty(t)
    t = T;
else
    t = direction * t(:);
    t = t( and(t >= T(1),t <= T(end)) );
    t = sort(t);
end

y0 = intval(y0);

nx = 20;                              % number of discretization subintervals of [-1,1]. Feel free to change this number! 
x = linspace(-1,1,nx)';               % discretization of the standard domain [-1,1]

len_x = length(x);
idx_x = 1:len_x;                      % index set of x
if n == 2
    I = idx_x';
    len_I = length(I);
    I_ = flipud(I);
    E = ones(len_I,1);
    E_ = len_x*E; 
    J = [I E_;E_ I_;I_ E;E I];        % clockwise index walk on the boundary of the square [-1,1]x[-1,1] starting at the upper left corner (-1,1)   
else
    [I_{n-1:-1:1}] = ndgrid(1:len_x); % Construct index array I the rows of which contain all ordered choices of n-1 elements from idx_x with repetitions.
    I = reshape(cat(n,I_{:}),[],n-1); % Then, x(I) is a discretization of the (n-1)-dimensional cube [-1,1]^n.
    I = idx_x(I);
    I = [I;I];                        % doubling of the indices
    len_I = length(I);
    E = ones(len_I/2,1);
    E = [E;len_x*E];                  % Note that 1 and len_x are the indices of the boundary points of [-1,1], i.e., x(1) = -1 and x(len_x) = 1.
    len_J = n*len_I;
    J = zeros(len_J,n);               % Now, out of I  and E, an index array J is constructed such that x(J) is a discretization of the boundary of the n-dimensional cube [-1,1]^n.
    j1 = 1;
    j2 = len_I;
    for i = 1:n                       % Insert E as i-th column "between" the columns of I for i = 1:n.
        J(j1:j2,1:i-1) = I(:,1:i-1);  % Columns 1,...,i-1 of J are those of I.
        J(j1:j2,i) = E;               % Column i of J is E.
        J(j1:j2,i+1:n) = I(:,i:n-1);  % Columns i+1,...,n of J are the remaining colums i,...,n-1 of I.
        j1 = j1 + len_I;
        j2 = j2 + len_I;
    end
end
xJ = x(J);
%plot(xJ(:,1),xJ(:,2),'r');           % Visualization of the discretization if n = 2. For testing only! 
%plot3(xJ(:,1),xJ(:,2),xJ(:,3),'*r'); % Visualization of the discretization if n = 3. For testing only! 

len_T = length(T);          
Y_i1 = Y(:,i1);            % first solution component  (x-axis)
Y_i2 = Y(:,i2);            % second solution component (y-axis) 
h_max = 0.001;             % maximum time grid width for plotting the midpoint trajectory. Feel free to change this value!
H = min(diff(T),h_max);    % time grid widths for plotting the midpoint trajectory
z = zeros(1,n);

figure
hold on
xlabel(['y_',num2str(i1)]);
ylabel(['y_',num2str(i2)]);

% Plot verified interval enclosures at time points t
if box
    [~,yb] = verifyode_disp(T,[Y_i1,Y_i2],Yr,[y0(i1);y0(i2)],t,false);
    plot(yb(:,1),yb(:,2),'w'); hold on
end

YY_i1 = [];
YY_i2 = [];
Yt_i1 = [];
Yt_i2 = [];

for j = 1:len_T-1
    y_i1 = Y_i1(j);                           % y_i1 and y_i2 are the (left) Taylor models for the compuonents i1 and i2 for the j-th integration step.
    y_i2 = Y_i2(j);
    if ~isempty(Yr)
        yr = Yr(j,:);                         % yr is the right Taylor model for the j-th integration step.
        z = get_constant_term(yr);            % z is the constant part of the polynomial part of yr, roughly speaking z = yr(0). 
    end        
    if j == 1
        t_ = t( and(T(j) <= t,t <= T(j+1)) ); % t_ contains all time points of t in [T(1),T(2)].        
    else
        t_ = t( and(T(j) <  t,t <= T(j+1)) ); % t_ contains all time points of t in ]T(j),T(j+1)].
    end
    h = (0:H(j):T(j+1)-T(j));                 % Subdivide [0,T(j+1)-T(j)] so that the plot of the center trajectory becomes more smooth.  
    if ~isempty(t_)  
        h_ = t_ - T(j);                       
        h_ = h_(:)';                          % conversion to row vector
        h = sort([h,h_]);                     % Add the time points of t_ to the time descretization for the center trajectory.  
        yt_i1 = center_trajectory(h_,y_i1,z); % yt_i1 and yt_i2 represent the center trajectory for time subinterval [T(j),T(j+1)] only evaluated at t_ 
        yt_i2 = center_trajectory(h_,y_i2,z);  
        Yt_i1 = [Yt_i1;yt_i1];                % Append the partial result yt_i1, yt_i2 for time points in t_ to the result Yt_i1, Yt_i2 for all time points in t.
        Yt_i2 = [Yt_i2;yt_i2];
        for ht = h_                           % Plot curvy enclosure sets at all time points in t_ . 
            if j == 1 && ht == 0              % At begin of integration the initial value interval vector y0 gives the exact enclosure.
                plot(y0(i1),y0(i2),'w')       % Plot this interval enclosure as a (white) box.
            else
                if isempty(Yr)
                    xr = xJ;
                else
                    xr = eval_(yr,xJ);
                end
                z_i1 = eval_(y_i1,xr,ht);
                z_i2 = eval_(y_i2,xr,ht);
                if n == 2
                    plot(z_i1,z_i2,'-g');     % Plot the boundary of the curvy enclosure set in green.
                else
                    %k = boundary(z_i1,z_i2);
                    %plot(z_i1(k),z_i2(k),'.g'); % Plot the boundary of the curvy enclosure set. 
                    
                    %plot(z_i1,z_i2,'.g');
                    plot(z_i1,z_i2,'.g','MarkerSize',1); % Plot (a superset of) the boundary of the curvy enclosure set using green dots. 
                                                         % For dimensions n > 2 the exact 2d-boundary of this set is hardly computed. 
                                                         % Feel free to suggest or implement a better visualization for this higher dimensional case.
                end
            end
        end
    end
    yy_i1 = center_trajectory(h,y_i1,z);      % yy_i1, yy_i2 describes the center trajectory for time subinterval [T(j),T(j+1)]
    yy_i2 = center_trajectory(h,y_i2,z);  
    YY_i1 = [YY_i1;yy_i1];                    % Append this partial results for [T(j),T(j+1)] to the final result YY_i1, YY_i2 for the whole time domain [T(0),T(end)]. 
    YY_i2 = [YY_i2;yy_i2];
end

%plot(YY_i1,YY_i2,'.-b');                     % phase portrait plot of center trajectory
plot(YY_i1,YY_i2,'-b');                       % phase portrait plot of center trajectory
plot(Yt_i1,Yt_i2,'.r','MarkerSize',10);       % phase portrait plot of center trajectory at time points of t
if nargin == 9 && ~isempty(transparency) && ~INTLAB_CONST.OCTAVE
    alpha(transparency)                       % set transparancy for overlaid objects
end
axis image

end % function verifyode_phase_portrait

function r = center_trajectory(h,y,z)
% nonverified evaluation of the polynomial parts of the center trajectory y(z,t-t0) at centered time points h = t-t0.
    c = y.coefficient;  % c contains the polynomial coefficients.
    M = y.monomial;     % M contains the polynomial exponents in its rows.
    N = M(:,end);       % N contains the time exponents.
    M = M(:,1:end-1);   % M contains the exponents for the space-like variables x_1,...,x_n, empedded in a 3d-array M_
    z_ = prod(z.^M,2);  % Build the products z(1)^M(j,1)*...*z(n)^M(j,n) for all j = 1,2,... .
    t_ = h.^N;          % Build the dyadic product of the time powers h(j)^N(i) which is a matrix.
    r = sum(c.*z_.*t_); % Multiply with coefficients and sum all up to get r = y(z,h).
    r = r(:);           % Convert the result to a column vector.
end % function center_trajectory

function r = eval_(y,x,h)
% nonverified evaluation of the polynomial parts of the Taylor model y at points x,h,
% where h is a fixed, centered time point. Roughly speaking r := y(x,h) is computed.

m = length(y);                    % m is the number of single Taylor models in y. 
                                  % If y is a left Taylor model, then m = 1, and
                                  % if y is a right Taylor model, then m = n. 
r = zeros(size(x,1),m);           % storage preallocation of result array t
x_(:,:,1) = x;                    % Extend the 2d-array x to a 3d-array x_. 
for i = 1:m
    y_ = y(i);                    % y_ is the i-th single Taylor model in y.
    M = y_.monomial;              % The rows of M contain the polynomial exponents.
    N = M(:,end);                 % N contains the exponents for the time variable h.
    c = y_.coefficient;           % c contains the polynomial coefficients.
    if nargin == 3 && ~isempty(h)
        c = c.*h.^N;              % Multiply the coefficients with the N-powers of h.
    end
    clear M_;
    M_(1,:,:) = M(:,1:end-1)';    % M_ contains the exponents for the space-like variables x_1,...,x_n embedded in a 3d-arry M_.
    X1 = x_.^M_;                  % Each row of x_ containing a specific discretization point is exponentiated with M_.
    X2 = squeeze(prod(X1,2));     % Along dimension 2 of X1 the monomial products  x(k,1)^M(j,1) * ...* x(k,n)^M(j,n), k = 1,2,... are computed
    X3 = X2.*c';                  % Next, the coefficients are multiplied: c(j).*x(k,1)^M(j,1) * ...* x(k,n)^M(j,n)
    X4 = sum(X3,2);               % Finally, everything is summed up: sum_j c(j).*x(k,1)^M(j,1) * ...* x(k,n)^M(j,n).
                                  % This is the polynomial part image y_(x(k,:),h) of the point x(k,:) = (x(k,n),...,x_(k,n)) at (centered) time h.
                                  % Everything is vectorized for k = 1,2,..., number of discretization points.
    r(:,i) = X4;                  % The result for y_ = y(i) is writen to the i-th column of the result array r.
end
end % function eval_

