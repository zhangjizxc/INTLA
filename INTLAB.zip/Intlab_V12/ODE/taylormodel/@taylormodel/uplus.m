function a = uplus(a)
%UPLUS  Taylor model unary plus +a
%
%   a = uplus(a) 

% written  08/24/15     F. Buenger

end % function uplus
