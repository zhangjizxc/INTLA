function Q = curvilinear(y,a,b,t,odefun,k,reffun)
%CURVILINEAR   computes a nearly orthogonal matrix Q for curvilinear preconditioning of depth k.
%
%  A = curvilinear(y,a,b,t,odefun,k,reffun)
%
%  The returned matrix Q is just a heuristic preconditioner. 
%  All computations are done in non-verfied floating-point arithmetic. 
%
%   input: 
%       y: integrated, time dependent current left Taylor model for the time interval [t_i,t_{i+1}].
%       a: integrated, time independent current left Taylor model: "a(x) = y(x,t_{i+1}-t_i)". 
%          Its range a(B), B := [-1,1]^n, encloses the initial value set for the next integration step on [t_{i+1},t_{i+2}]. 
%       b: current right Taylor model. The more precise initial value set for the next integrationstep on [t_{i+1},t_{i+2}]
%          is the range a(b(B)) which is a subset of a(B) as b(B) is a subset of B. 
%       t: t = t_{i+1} is the starting time for the next integration step on [t_{i+1},t_{i+2}].
%  odefun: ODE function handle
%       k: depth of curvilinear basis used for curvilinear preconditioning      
%  reffun: optional user-specified reference trajectory
% 
%   output: 
%       Q: nxn-matrix containing the curvilinear basis of depth k in its columns, 
%          where n is the dimension of the treated ODE. 
%          According to [MB] (reference see below), this means that the columns           
%          Q(:,1),...,Q(:,n) of Q are the Gram-Schmidt orthonormalization of 
%           
%          X := ( q_1,q_2,...,q_k,e_1,...,e_{n-k} )         
%
%          where q_j := y_r^{(j)}(0), 1 <= j <=k, is the j-th time derivative of a reference curve/trajectory y_r(t) at t = 0 
%          (t = 0 corresponds to the left boundary t_{i+1} of the next time step on [t_{i+1},t_{i+2}]) and
%          e_1, ..., e_{n-k} are arbitrary unit vectors which are perpendicular to q_1, q_2,..., q_k.  
%          Here, "reference curve" means that y_r(t) fullfills the ODE, that is y_r'(t) = f(y_r(t),t-t_{i+1}), 
%          and the point initial value y_r(0) is contained in the initial value set for the next time step on [t_{i+1},t_{i+2}]. 
%          The index "r" in y_r stands for "reference" and not for "right", so do not get confused with the right Taylor model
%          which is the input argument b. 
%
%  The implementation is based on: 
%
%  [MB1]  Kyoko Makino and Martin Berz, Suppression of the wrapping effect by Taylor model - based validated integrators,
%           MSU HEP Report 40910, 2003 
%  [MB2]  Kyoko Makino and Martin Berz, Suppression of the Wrapping Effect by Taylor Model-based Verified Integrators: Long-term Stabilization by Preconditioning,
%           International Journal of Differential Equations and Applications 10(4), 105-136, 2005

% written  10/01/19     F. Buenger

% For testing we implemented four different methods for choosing the reference trajectory y_r(t) and computing its derivatives. 
% Methods 1,2 use automatic differentiation while methods 2,3 use the Taylor models y and b, see the desription of the input parameters.

% computation of the derivatives of a reference trajectory by automatic differentiation using INTLAB's taylor toolbox
%method = 1; % Take intial value y_r(0) := a(0)    as starting point of the reference trajectory y_r(t) at t = t_{i+1}.
%method = 2; %       - " -       y_r(0) := a(b(0))          - " -

% computation of the derivatives of a reference trajectory by using the Taylor models y and b from the previous time step
method = 3; % take reference trajectory  y_r(t) := y(0,t+(t_{i+1}-t_i)),     see the description of the input parameter y. 
%method = 4; %         -"-                y_r(t) := y(b(0),t+(t_{i+1}-t_i))          - " -

%global CL_METHOD

y_ = y(1);
n = y_.dim-1; 

%switch CL_METHOD   
if isempty(reffun)
    switch method
        case 1 % method 1: y_r(0) := a(0) , automatic differentiation
            
            a0 = get_constant_term(a);
            x = taylorinit(a0,k);         % type taylor object of Taylor order k for point initial value c0
            x = odetaylor(t,x,odefun);    % Compute Taylor coefficients up to order k which are stored in the component x.t.
            x_t = struct(x);
            x_t = x_t.t(2:k+1,:)';        % Since x.t(1) is the ode function value (0-th derivative), the indexing starts from 2.
            X = x_t.*factorial(1:k);      % For j = 1,...,k, the j-th column of X contains the j-th time derivative of x_r at t = t_{j+1}.
            
        case 2 % method 2: y_r(0) := a(b(0)) , automatic differentiation
            b0 = get_constant_term(b);    % b0 := b(0)
            b0 = b0(:)';                  % conversion to row vector
            yr0 = zeros(n,1);
            for m = 1:n
                a_ = a(m);
                c = a_.coefficient;             % polynomial coefficients of a_
                M = a_.monomial;                % corresponding polynomial exponents
                M = M(:,1:end-1);               % exponents of space-like variables x_1,...,x_n. Recall that the Taylor model a_ is time independent, i.e., M(:,end) = 0.
                yr0(m) = sum(c.*prod(b0.^M,2)); % yr0 := a_(b(0))
            end
            x = taylorinit(yr0,k);        % type taylor object of Taylor order k for point initial value yr0
            x = odetaylor(t,x,odefun);    % Compute Taylor coefficients up to order k which are stored in the component x.t.
            x_t = struct(x);
            x_t = x_t.t(2:k+1,:)';        % Since x.t(1) is the ode function value (0-th derivative), the indexing starts from 2.
            X = x_t.*factorial(1:k);      % For j = 1,...,k, the j-th column of X contains the j-th time derivative of x_r at t = t_{j+1}.
            
        case 3 % method 3: y_r(t) := y(0,t+(t_{i+1}-t_i))
            h = y_.domain.sup(n+1)-y_.domain.inf(n+1); % h = t_{i+1}-t_i is the step size of the last integration step.
            X = zeros(n,k);
            for m = 1:n
                y_ = y(m);              % copy of i-th component of y
                M = y_.monomial;        % exponents of polynomial part
                c = y_.coefficient;     % ... corresponding polynomial coefficients
                row = ~any(M(:,1:n),2); % index of x-independent exponents which are in columns 1,...,n of M
                N = M(row,n+1);         % ... corresponding time exponents which are in column n+1 of M
                c = c(row);             % ... corresponding coefficients
                                        % => p(t) := y_(0,t-t_i) = \sum_j c(j)*(t-t_i)^N(j) is the approximate for the center trajectory
                                        %    for which the first k derivatives at t = t_{i+1} must be computed.
                N = repmat(N,1,k);      % N := [N,N,...,N], k-fold repetition of N
                U = max(N-(0:k-1),0);   % Build the derivates  of order j = 1,...,k of the univariate polynomial p^{(j)}(t)
                U = cumprod(U,2);       % by elementary calculus.
                V = max(N-(1:k),0);
                W = (c.*U).*(h.^V);     % The final evaluation is done at t = t_{i+1}, recall that h = t_{i+1}-t_i.
                X(m,:) = sum(W);        % X(m,j) := p^{(j)}(t_{i+1})
            end
            
        case 4 % method 4: y_r(t) := y(b(0),t+(t_{i+1}-t_i))
            b0 = get_constant_term(b);  % Get constant part b0 := b(0) of right Taylor model b.
            b0 = b0(:)';                % Convert b0 to row vector.
            h = y_.domain.sup(n+1)-y_.domain.inf(n+1); % h = t_{i+1}-t_i is the step size of the last integration step.
            X = zeros(n,k);
            for m = 1:n
                y_ = y(m);              % copy of i-th component of y
                M = y_.monomial;        % exponents of polynomial part
                c = y_.coefficient;     % ... corresponding polynomial coefficients
                N = M(:,n+1);           % exponents of time variable t
                M = M(:,1:end-1);       % exponents of space-like variables x_1,...,x_n
                c_ = c.*prod(b0.^M,2);  % c_(j) := c(j)*b0(1)^M(j,1)*...*b0(n)^M(j,n) , j = 1,...,length(c)
                c_ = accumarray(N+1,c_);% Sum up all coefficients c_ with the same time exponent j and store that sum in c_(j).
                N = find(c_)-1;         % Consider only non-zero coefficients.
                c_ = c_(N+1);           %
                                        % => p(t) := y_(b0,t-t_i) = \sum_j c_(j)*(t-t_i)^N(j) is the approximate for the center trajectory
                                        %    for which the first k derivatives at t = t_{i+1} must be computed.
                N = repmat(N,1,k);      % N := [N,N,...,N], k-fold repetition of N
                U = max(N-(0:k-1),0);   % Build the derivates  of order j = 1,...,k of the univariate polynomial p^{(j)}(t)
                U = cumprod(U,2);       % by elementary calculus.
                V = max(N-(1:k),0);
                W = (c_.*U).*(h.^V);    % The final evaluation is done at t = t_{i+1}, recall that h = t_{i+1}-t_i.
                X(m,:) = sum(W);        % X(m,j) := p^{(j)}(t_{i+1})
            end
    end
else % user-specified reference curve
    t_ = taylorinit(t,k);      % type taylor object of taylor order k for starting time t    
    x = reffun(t_);            % Compute the (scaled) derivatives of the reference trajectory up to order k by (non-verified) automatic differentiation.
    x_t = struct(x);           % Convert x of type "taylor" to a simple structure.
    x_t = x_t.t(2:k+1,:)';     % Since x.t(1) is the function value (0-th derivative), the indexing starts from 2.
    X = x_t.*factorial(1:k);   % Adapt the scaling in order to get the real, unscaled derivatives.
end
           
if k<n
    I = eye(n);
    [Q_,~] = qr(X,0);                % nxk-economy size QR-decomposition of X.
    S = I-Q_*Q_';
    normsS = sqrt(sum(S.*S));        % non-verified computation of the Euclidean norms of the column vectors of S
    [~,iS] = sort(normsS,'descend'); % The variable "normsS" is not used later on. Only the permutation iS is of interest.
    X = [X,I(:,iS(1:n-k))];          % Append the first n-k columns of I to X. These are the n-k standard unit vectors  
                                     % that have the largest distance to the subspace spanned by the columns of X. 
                                     % Among all possible choices of n-k standard basis vectors this specific choice
                                     % aimes to yield a reasonably well-conditioned extended matrix X.
end

[Q,R] = qr(X);            
d = sign(diag(R));        
d(d == 0) = 1;            
Q = Q.*d';   

end % function curvilinear