function B = blunt(A,options)
%BLUNT   blunting of matrix A
%
%   B = blunt(A)
%
%   input: 
%       A:       nxn - matrix
%    options:    global options that can be spacified by the user
%
%   output: 
%       B:       nxn - matrix, q-bluntig of A. 
%
%
%   First, the columns of A are sorted according to Euclidean length in descending order.
%   For this column-reordered matrix a QR-factorization is carried out 
%    
%   (1) As = A*P,  As = QR, 
%
%   where Q is taken such that all diagonal entries of R are nonnegative and P denotes a suitable 
%   permutation matrix. Then, compute 
% 
%   (2) B := As + Q*diag(q) = Q*(R+diag(q)) 
%  
%   for a vector q = (q_1,...,q_n) > 0 componentwise. 
%   Since the diagonal entries of the upper triangular matrix R are nonnegative, B is always regular.
%   Finally, the columns of B are rearranged to the original order of A, i.e., the result
%
%   (3) B := B*P^T = A + Q*diag(q)*P^T. 
%
%   is the returned "q-blunting" of A.
%
%   The purpose of blunting is that B has a better condition number than As which of course depends on the 
%   blunting factors q_i. These blunting factors q_i are heuristically chosen. 
%
%   In [MB_2003] p.33, [MB_2006_a] p.17, [MB_2006_b] p.20, see the references below, a constant attempt is suggested 
%   which we followed in INTLAB Version 11:
%   "Chose the blunting factors q_i to be 1E−3 times the length of the longest column vector of the linear matrix." 
%   Thus all q_i have the same single value. 
% 
%   In INTLAB Version 11.1 we switched to columnwise different blunting factors in the spirit of [NJN2], 
%   see the references below, and chose 
%
%   (4) q_i := epsilon * norm(As(:,i)) , 
%
%   where norm(As(:,i)) is the  Euclidian norm of the i-th column of the matrix As = A*P and 
%   epsilon := e := options.blunting_factor can be chosen by the user via setting the option "blunting factor". 
%
%   Note that blunting does not need any verified computations.
%
%
%  [MB_2003]   K. Makino and M. Berz, "Suppression of the wrapping effect by Taylor model - based validated integrators",
%                MSU HEP Report 40910, 2003, mainly pages 20,21 
%
%  [MB_2006_a] K. Makino and M. Berz, "Suppression of the Wrapping Effect by Taylor Model-based Verified Integrators: Long-term Stabilization by Preconditioning",
%                International Journal of Differential Equations and Applications 10(4) (2005), 353-384
%
%  [MB_2006_b] K. Makino and M. Berz, "Suppression of the Wrapping Effect by Taylor Model-based Verified Integrators: Long-term Stabilization by Shrink Wrapping",
%                International Journal of Differential Equations and Applications 10(4) (2005), 385-403
%
%  [NJN2]      M. Neher, K.R. Jackson, N.S. Nedialkov, "On the blunting method in verified integration of ODEs", Reliab. Comput. 23 (2016), 15-34  

% written  06/28/17     F. Buenger
% modified 01/09/17     F. Buenger  columnwise individual blunting factors
% modified 09/25/19     F. Buenger  second input parameter blunting_factor added

cond_bound = 1E2;                     % bound for the nonverified condition number cond(A) of A
                                      % This bound is chosen quite arbitrarily. Feel free to change that! 
                                      % If blunting is switched on and cond(A) > cond_bound, then blunting is executed.
cond_A = cond(A);
if cond_A < cond_bound
    B = A;                            % If A is quite well-conditioned, then B := A is returned unchanged. 
    return; 
end

normsA = sqrt(sum(A.*A));             % non-verified computation of the Euclidean norms of the column vectors of A
[normsA,iA] = sort(normsA,'descend'); % Sort the column norms of A in descending order. The corresponding permutation matrix P, see (1),
                                      % is only implicitly given by the index set iA. 
As = A(:,iA);                         % The columns of A are sorted by Euclidean length in descending order: As := A*P, see (1).
[Q,R] = qr(As);                       % Compute a non-verified QR decomposition As = Q*R.
d = sign(diag(R));                    % d := (sign(R_11),...,sign(R_nn))
d(d == 0) = 1;                        % Set d_i := 1 if R_ii = 0.
Q = Q.*d';                            % Q := Q*diag(d) is normalized such that R has nonnegative diagonal: 
                                      % As = Q*R = (Q*diag(d)) * (diag(d)*R) where the adapted 
                                      % R := diag(d)*R with R_ii >= 0 is not explicitly needed.         

%-------------------------------------------------------------------------------------------------------------------
% INTLAB Version 11: constant blunting factors
%-------------------------------------------------------------------------------------------------------------------
% [MB_2003] p.33, [MB_2006_a] p.17, [MB_2006_b] p.20:
%   "Choose the blunting factors q_i to be 1E−3 times the length of the longest column vector of the linear matrix."  
%
% e = 1E-3;                      % heuristic stretching factor
% q_min = 1e-13;                 % heuristic lower bound for scaling factor q. Feel free to change that! 
% q = max(e * normsA(1),q_min);
% B = As + q*Q;                  % B := As+q*Q = A*P+q*Q
% B(:,iA) = B;                   % B := B*P{-1} = A + Q*diag(q)*P^T final reordering of columns of B, see (3) 

%-------------------------------------------------------------------------------------------------------------------
% INTLAB Version 11.1: columnwise different blunting factors 
%-------------------------------------------------------------------------------------------------------------------
% alternative, individual choice of blunting factors in the spirit of [NJN2], pp. 22-25: 
% q_i := e * ||As(:,i)|| = e * (length of i-th column of As)

e = options.blunting_factor;
q = e*normsA;  % blunting factors, see (4)
B = As + Q.*q; % B := As + Q*diag(q), see (2)
B(:,iA) = B;   % B := B*P^{-1} = A + Q*diag(q)*P^T final reordering of columns of B, see (3) 

% cond(B)/cond(A)  % ratio of condition number of input A and output B. Only for testing!

end % function blunt