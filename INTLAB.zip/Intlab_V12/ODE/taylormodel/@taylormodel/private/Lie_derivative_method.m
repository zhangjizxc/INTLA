function y = Lie_derivative_method(odefun,y0,t,base_tm,orders)
%LIE_DERIVATIVE_METHOD   computes the polynomial part of the Taylor model for the solution y(t,x) of the initial value problem (IVP)
%
%                          (1) y'(t,x) = f(t,y(t,x)), t in [t0,te]:=[t.inf(end),t.sup(end)], where f(t,y):=odefun(t,y), 
%                          (2) y(t0,x) = y0(x) in range(y0).
%
%                        This computation is done in non-verified Taylor model arithmetic and utilizes the Lie derivative method
%                        introduced by Makino and Berz in [MB1], [MB1].
%
%  y = Lie_derivative_method(odefun,y0,t,base_tm,orders)
%
%   input:
%      odefun: function handle for the right-hand side of the ODE (1)
%          y0: time independent Taylor model representing the initial value set at t0.
%           t: time Taylor model
%     base_tm: identity Taylor model
%      orders: individual orders up to which the corresponding variables shall occur in the polynomial part of the returned Taylor model y.
%              If "orders" is empty, then these individual orders are limited by the overall polynomial degree = y0(1).order.
%
%   output:
%           y: Taylor model for the IVP (1), (2). Only the polynomial part is computed, the error interval remains empty (non-verified Taylor model arithmetic).    
%
%
%   Description of the method, see the references [MB1], [MB2]:
%
%     Let n be the dimension of the ODE (1), (2).
%
%     Since all computations are done in non-verified Taylor model arithmetic, we identify Taylor models p(t,x)+I with their polynomial parts p(t,x).
%     Error intervals I are discarded, i.e., I := 0 is set to zero.
%
%     Recall that x = (x_1,...,x_n) in [-1,1]^n are the space-like variables and t in [t0,te] is the time variable.
%     Recall also that y0(t,x) = y0(x) is time-independent, and that range(y0) = image(y0) = y0([-1,1]^n) = {y0(x), x in [-1,1]^n}
%     is the initial value set on the right-hand side of (2).
%     (Note that range(y0) = image(y0) + I = image(y0) because error intervals I are discarded in non-verified Taylor model arithmetic.)   
%
%               
%     Step 1. Let c0 := y0(0) be the constant Term of y0.
%             Compute a Taylor model c only depending on time t for the so-called "center trajectory" c(t) := y(t,0) which by (3) has the point initial value
%            
%               (3) c(t0) = y(t0,0) = y0(0) = c0.  
%            
%             Here, this is done by using INTLAB's automatic differentiation. Alternatively, a cheap one-dimensional Picard iteration could be carried out as proposed in [MB2].
%            
%     Step 2. The function
%
%               (4) z(t,x) := y(t,x) - c(t)
%
%             solves the IVP
%
%               (5) z'(t,x) = f(t,c(t)+z(t,x)) - c'(t) =: F(t,z(t,x)).
%
%             The benefit of the new function z(t,x) with corresponding new ODE function F(t,z) is:
%
%               (6) z(t0,x) = y(t0,x) - c(t0) = y0(x) - y0(0)  ==> The image z(t0,[-1,1]^n) is "centered" around / contains zero.
%               (7) F(t,0) = f(t,c(t)) - c'(t) =  0            ==> The constant term of a Taylor expansion of F(t,z) with respect to z is zero (i.e. has very small absolute value in numerical practice).
%
%     Step 3. Introduce new space-like variables z = (z_1,...,z_n) [and consider each of them also as an elementary Taylor model of order one in a single variable]. 
%             Then, evaluate
%         
%               (8) P := F(t,z) 
%
%             in Taylor model arithmetic so that P = P(t,z) is an (approximate) Taylor expansion of the new ODE function F(t,z).
%            
%     Step 4. The Lie derivative of a smooth function g(t,z) = (g_1(t,z),....,g_n(t,z))^T with respect to F is defined by 
%
%               (9) L_F(g) = dg/dt + J_g*F ,
%             
%             where J_g = (dg_i/dz_j)_{1 <= i,j <= n} is the Jacobian matrix of g with respect to z, and dg/dt is the time derivative of g.              
%             Now, for k = 0,...,m, the k-th Lie derivative L^k_F(g) of g w.r.t. F is recursively defined by
%             
%               (10) L^0_F(g)      = g,
%               (11) L^(k+1)_F(g)  = L(L^k_F(g)).
%            
%             By (5) we have
%
%               (12) ( g(t,z(t,x)) )' = J_g(z(t,x)) * z'(t,x) + g'(t,z(x,t))= J_g(z(t,x))* F(t,z(t,x)) = L_F(g)(t,z(t,x))
%
%             which by trivial induction gives
%
%               (13) d^k/dt^k g(t,z(t,x)) = L_F^k(g)(t,z(t,x)), k = 0,...,m.
%
%             Therefore, a Taylor expansion of order m of g(t,z(t,x)) around t0 reads
%
%               (14) g(t,z(t,x)) = sum_{k=0}^m (t-t0)/k! L^k_F(g)(t0,z(t0,x))
%
%             For the special choice of g(t,z):= id_z(t,z):=z this gives a Taylor expansion of z(t,x): 
%
%               (15) z(t,x) = sum_{k=0}^m (t-t0)^k/k! L^k_F(id_z)(t0,z(t0,x)).
%
%             The k-th Lie-derivatives
%
%               (16) L^k_F(id_z)(t,z)
%
%             are approximated by
%
%               (17) L^k_P(id_z)(t,z), see (8), i.e., F is replaced by P.
%
%             (17) can be computed iteratively by evaluating (10), (11), (12) with F replaced by P and g replaced by id_z for the elementary Taylor models
%             z = (z_1,...,z_n) introduced in Step 3.
%             This is mainly done by what Makino and Berz [MB2] call "re-shuffling" of the Taylor coefficients and by Taylor model multiplication with P.  
%
%             Here, the numerical benefit (8) F(t,0) = 0 = P(t,0) is exploited: the lack of highest order derivatives due to differentiation becomes unimportant because
%             those highest order derivatives would have been multiplied with P(t,0) = 0 and would therefore not contribute anyway.
%
%             Finally, 
%             
%               (18) z(t0,x) = y(t0,x)-c(t0) = y0(x) - y0 =: z0 
%              
%             is available in Taylor model arithmetic and is substituted for z in (17).
%             Summing up according to (15) yields a Taylor model representation for z(t,x) which we also call z(t,x).
%
%     Step 5. According to (4), y(t,x) = z(t,x) + c(t) gives the wanted (non-verified) Taylor model representation for the solution y(t,x) of the IVP (1), (2).  
%             This is the returned by the function in the output argument y.
%
%     The advantage of the Lie derivative method is that only one single evaluation of the ODE function is necessary in Step 3, see (8).
%     In contrast, a Picard iteration needs many repeated evaluations of the ODE function.
%     However, the Taylor model substitution of z0 for z in (16) to evaluate (15) is quite expensive.
%
%
%  The implementation is based on:
%
%  [MB1]  K. Makino and M. Berz, Lecture Notes, Course Presented at Department of Mathematics, University of Barcelona, June 2008,
%           MSUHEP-080609, Slides 234-239, Michigan State University (2008)
%  [MB2]  K. Makino and M. Berz, Rigorous Integration of Flows and ODEs using Taylor Models,
%           Symbolic Numeric Computation 2009, (2009) 79-84

% written  01/28/20     F. Buenger

empty_iv.inf = [];
empty_iv.sup = [];

y_ = y0(1);
n = y_.dim-1;           % dimension of the ODE (1)
order = y_.order;       % common Taylor model order, maximum degree of all polynomial parts 
isempty_orders = isempty(orders); 


if isempty_orders
    m = order;
else
    m = orders(n+1);
end

[c0,idx] = get_constant_term(y0);    % c0 = y0(0), see Step 1
z0 = subtract_constant_term(y0,idx); % z0 := y0 - c0, see Step 4, equation (18)


c_trigger = 1;  % computation of the center trajectory c(t), see Step 1, by a (one-dimensional) Picard iteration
%c_trigger = 0;  % alternative computation of the center trajectory c(t) by using INTLAB's automatic differentiation

if c_trigger % computation of the center trajectory c(t), see Step 1, by a (one-dimensional) Picard iteration
    % Convert the n+1-dimensional Taylor model t to a one-dimensional Taylor model t_.
    t_ = t;                              % just preallocation
    t_.monomial = t.monomial(:,n+1);     % "one-dimensinal" time exponents, i.e., t_.monomial = [0;1]  
    t_.domain.inf  = t_.domain.inf(n+1); % one-dimensional domain
    t_.domain.sup  = t_.domain.sup(n+1);  
    t_.center  = t_.center(n+1);         % one-dimensional centering point
    t_.interval = empty_iv;              % In non-verified Taylor model arithmetic, error intervals and images are discarded.
    t_.image = empty_iv;                 % Thus, for clarity, they are set to "[]" (empty).
    t_.dim = 1;                          % t_ is a one-dimensional Taylor model.
    v = typeadjust(c0,t_);               % Convert float vector c0 to a one-dimensional Taylor model.
    
    % one-dimensional Picard iteration for center trajectory c(t) =: v(t)
    for k = 1:order
        t_ = set_order(t_,k);
        v = set_order(v,k);
        v_ = odefun(t_,v);
        v = c0 + integral(v_,1);
    end 
    
    % Transform one-dimensional Taylor model v(t) to n+1-dimensional Taylor model c(t), and compute also the derivative c'(t) =: dc(t).
    c = base_tm; % just preallocation
    dc = c;      % just preallocation for the derivative dc(t) := c'(t)    
    for i = 1:n
       c_ = c(i); 
       dc_ = dc(i);
       v_ = v(i);
       M = v_.monomial;            
       c_.monomial = [zeros(length(M),n),M];  % Add zero exponents vor the first leading n dimensions, i.e., for the space-like variables x_1,...,x_n.
       c_.coefficient = v_.coefficient;       
       c(i) = c_;
       idx = (M > 0);                        
       if any(idx)
           M = M(idx);
           dc_.monomial = [zeros(length(M),n),M-1];  % Add zero exponents vor the first leading n dimensions.
           dc_.coefficient = v_.coefficient(idx).*M; % coefficients of the derivative: (coeff * t.^M)' = (coeff .* M) t.^(M-1) 
       else
           dc_.monomial = zeros(1,n+1); % Empty monomials are avoided!
           dc_.coefficient = 0; 
       end
       dc(i) = dc_;
    end    
else  % alternative computation of the center trajectory c(t) by using INTLAB's automatic differentiation  
    sparsity_tol = get_sparsity_tol;
    x = taylorinit(c0,m);       % type taylor object of Taylor order m for point initial value c0.
    t0 = t.domain.inf(n+1);     % integration interval [t0,e], see (1)
    x = odetaylor(t0,x,odefun); % Compute Taylor coefficients up to order m of the center trajectory c(t). These coefficients are stored in the component x.t.
    x_t = struct(x);
    X = x_t.t(1:m+1,:)';        % For j = 0,...,m, the j-th column of X  contains the j-th Taylor coefficient c^(j)(t0)/j! of c(t) at t = t0. 
    dX = X(:,2:m+1).*(1:m);     % For j = 1,...,m, the j-th column of dX contains the j-th Taylor coefficient c^(j+1)(t0)/j! of c'(t) at t = t0.
    
    c = base_tm;                % just cheap preallocation
    dc = base_tm;               % ... and once more
    M = [zeros(m+1,n),(0:m)'];  % array of exponents for the time powers t^0,t^1,...,t^m
    % The leading zeros are the exponents of the absent space-like variables x_i, i = 1,...,n.
    for i = 1:n
        c_ = c(i);
        coeff = X(i,:)';                    % Taylor coefficients for the i-th component function c_i(t) of the center trajectory c(t)
        idx = (abs(coeff) >= sparsity_tol); % Only Taylor coefficients with absolute value greater than or equal to the user-specified sparsity tolerance will be taken into account.
        if all(idx == 0)
            c_.monomial = zeros(1,n+1);     % Empty polynomials are avoided!
            c_.coefficient = 0;
        else
            c_.monomial = M(idx,:);         % Taylor coefficients with absolute value below the user-specified sparsity tolerance are discarded.
            c_.coefficient = coeff(idx);
        end
        c_.interval = empty_iv;             % In non-verified Taylor model arithmetic error intervals are discarded,
        c_.image = empty_iv;                % ... and also the polynomail image is irrelevant.
        c(i) = c_;                          % Store the result in c(i).
        
        % Analogously, construct a Taylor model dc for the derivative c'(t) of the center trajectory c(t).
        dc_ = dc(i);
        coeff = dX(i,:)';
        idx = (abs(coeff) >= sparsity_tol);
        if all(idx == 0)
            dc_.monomial = zeros(1,n+1);
            dc_.coefficient = 0;
        else
            dc_.monomial = M(idx,:);
            dc_.coefficient = coeff(idx);
        end
        dc_.interval = empty_iv;
        dc_.image = empty_iv;
        dc(i) = dc_;
    end
end

% c = c0; % For testing only!
% dc = 0; % For testing only!

P = odefun(t,c + base_tm) - dc; % Taylor model P for the ODE function F(t,z) := odefun(t,c(t)+z) - c'(t), see Steps 2 and 3, equations (5) and (8)

% computation of the Lie derivatives, see Step 4

J(1:n,1:n+1) = t; % just preallocation 
g = base_tm;      % Taylor model for g(t,z) := id_z, see Step 4, equations (14) and (15).
S = base_tm;
k_factorial = 1;  
for k = 1:m
    k_factorial = k_factorial * k;    
    L = Lie_derivative(J,P,g,n); % Compute a Taylor model L for the k-th Lie-derivative L^k_P(id_z)(t,z), see Step 4, equation (17).       
    
    % Insert (t0,z0) for (t,z) in L^k_P(id_z)(t,z), i.e., compute a Taylor model L0 for L^k_P(id_z)(t0,z(t0,x)) in order to evaluate the k-th addend in (15). 
    % Actually, for the moment only t0 is inserted for t, and the new variable z remains. 
    % The expensive substitution of z0 for z is done after the loop by one single call of the function "concatenate".
        
    for i = 1:n
        L_ = L(i); 
        M = L_.monomial;
        idx = (sum(M,2) <= m-k);                   % Since L_, which represents = L^k_P(id_z), is multiplied by (t-t_0)^k (see (15)) only orders up to m-k
                                                   % are considered in Taylor model arithmetic with maximum time exponent m.
                                                   % This order reduction is mainly done for performance reasons.
        if any(idx)
            M = M(idx,:);                          % Discard entries for time exponents > m-k, ... 
            L_.monomial = M;                        
            L_.coefficient = L_.coefficient(idx);  % ... and also the corresponding coefficients.
            L(i) = L_;                             % Update L.  
            idx0 = (M(:,n+1) == 0);                % Substitution of t by t0 in the centered terms (t-t0)^j, j>0, of the Taylor model L means that all time-dependent terms vanish.
                                                   % The index "idx0" selects the remaining time-independent terms.
            if any(idx0)
                Sk_ = L_;
                M = M(idx0,:);                     % All time-dependent terms are discarded.
                M(:,n+1) = k;                      % This resembles the multiplication by (t-t_0)^k, see (15).
                Sk_.monomial = M;
                Sk_.coefficient = Sk_.coefficient(idx0)/k_factorial; % division by k!, see (15).
                S(i) = S(i) + Sk_;                 % Update the Taylor series by adding k-th addend, see (15).                                                   
            end
        else
            L_.monomial = zeros(1,n+1);
            L_.coefficient = 0;                        
            L(i) = L_;
        end
    end    
    g = L; % Update g to L which represents L^k_P(id_z)(t,z) in order to compute L^(k+1)_P(id_z) = L_P(L^k_P(id_z)) in the next iteration. 
end

z = concatenate(S,z0); % Substitute z0 for z in S.

y = c + z; % Step 5: y(t,x) = z(t,x) + c(t) is the wanted (non-verified) Taylor polynomial / model for the solution y(t,x) of the original IVP (1), (2)

end % function Lie_derivative_method


function L = Lie_derivative(J,f,g,n)
% LIE_DERIVATIVE   computes the (approximate) Lie derivative L_f(g) =  dg/dt + J_g*f + dg/dt of g with respect to f
%                  where J_g = [(dg_i/d_xj),dg/dt] is the Jacobian matrix of g. See Step 4, equation (9). 
for i = 1:n
    g_ = g(i);
    M = g_.monomial;
    coeff = g_.coefficient; 
    for j = 1:n+1
        a = J(i,j);
        Mj = M(:,j);                      % exponents for variable x_j
        idx = (Mj > 0);                   % idx of exponent row vectors with nonzero exponent for variable x_j.     
        if all(idx == 0)
            a.monomial = zeros(1,n+1);    % Empty polynomials are avoided!
            a.coefficient = 0;  
        else
            M_ = M(idx,:);                % partial differentiation: d/dx_j coeff * x_j^m = coeff * m * x_j^(m-1)
            M_(:,j) = M_(:,j)-1;
            coeff_ = coeff(idx).*Mj(idx); 
            a.monomial = M_;
            a.coefficient = coeff_;
        end
        J(i,j) = a;                       % Adapt the (i,j)-entry of the Jacobian matrix J = J_g = (dg_i/d_xj), 1 <= i <= n, 1 <= j <= n+1, where x_n+1 := t.  
    end
end
Jx = J(:,1:n);    % The first n columns of J = J_g contain the derivatives dg/dxj w.r.t the space-like variable x_j, j = 1,...,n.
Jt = J(:,n+1);    % The last, n+1-th column of J = J_g contains the time-derivative dg/dt.
L = Jx * f + Jt;  % <=> L = J * (f;1). The implicitly given ODE component function for the time variable t is t' = 1.   

end % function Lie_derivative 

