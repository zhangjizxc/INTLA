function res = polynom2taylormodel(p,center,domain,order,interval,type)
%POLYNOMIAL2TAYLORMODEL   transform p of type 'polynomial' to a taylormodel.
%
%   res = polynom2taylormodel(p)                                     % simple call
%   res = polynom2taylormodel(p,center,domain,,order,interval,type)  % advanced call

% written  01/22/16     F. Buenger
% modified 02/11/16     F. Buenger  "intval"-components --> intval-like structures
% modified 01/17/19     F. Buenger  additional, optional input arguments center,domain,interval,type
% modified 01/29/19     F. Buenger  additional, optional input argument order; also order >= 1 enforced if not provided

if ~isa(p,'polynom') ||  ~( isfloat(p.c) && isreal(p.c) )
    error('p must be a polynomial with real floating-point coefficients.')
end
if ~ ( isfloat(p.c) && isreal(p.c) )
    error('p must have type polynom')    
end

if nargin < 6 || isempty(type)
    type = [];
end
if nargin < 5 || isempty(interval)
    interval = [];
end

% In the univariate case q.e is simply the polynomial degree.
% In the multivariate case q.e is a nontrivial matrix which contains
% in each row the exponents of a monomial.

if numel(p.e) == 1 % univariate case
    if nargin < 2 || isempty(center)
        center = 0;                                   % default evaluation point zero
    end
    if nargin < 3 || isempty(domain)
        domain.inf = -1;                              % default domain [-1,1]
        domain.sup = 1;
    end    
    if nargin < 4 || isempty(order)
        order = max(p.e,1);                           % = degree of p   
    end    
    [dummy,monomial,coefficient] = find(fliplr(p.c)); % type 'taylormodel' uses sparse notation while 'polynom' 
                                                      % uses full notation for univariate polynomials 
    monomial = monomial' - 1;                         % polynomial exponents                                             
    coefficient = coefficient';  
else % multivariate case
    if nargin < 4 || isempty(order)
        order = max(max(sum(p.e,2)),1);               % maximal degree
    end    
    coefficient = p.c;
    monomial = p.e;
    n = length(monomial(1,:));                        % number of variables, p = p(x1,...,xn)
    if nargin < 2 || isempty(center)
        center = zeros(n,1);                          % default evaluation point t_0(i) = 0, i = 1,...,n.
    end
    if nargin < 3 || isempty(domain)
        domain.inf = -ones(n,1);                      % default domain := [-1,1]^n 
        domain.sup = ones(n,1);  
    end
end

res = taylormodelinit(center,domain,order,monomial,coefficient,interval,type);

end % function polynom2taylormodel