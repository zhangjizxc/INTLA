function [C,C_] = sconv(A,B,verified)
% SCONV  convolution of two column vectors A and B. 
%        The result is always sparse while A and B can be sparse or full.
%        This is in contrast to the MATLAB functions conv and conv2  which 
%        do not accept sparse input.
%        The third input parameter "verified" can take the values "true"
%        for verified computation of conv(A,B) in [C_,C], or "false" for  
%        nonverified computation of C :=  conv(A,B), C_ := []. 
%        In verified mode it is assumed that rounding is switched to upwards.
%
% [C,D] = sconv(A,B)

% written  05/09/17     F. Buenger
% modified 09/09/19     F. Buenger new input parameter "verified", two return parameters [C,D]

m = length(A);
n = length(B);

%[i,~,a] = find(A);      % The "~"-notation is not downward-compatible for older MATLAB versions.
[i,dummy,a] = find(A);   % Therefore a "dummy"-variable is stated which is not used in the sequel.  
if isempty(i) % A is sparse zero
    C = A;    % => return sparse zero
    if verified
        C_ = C;
    end
    return;
end

%[j,~,b] = find(B);      % See above.
[j,dummy,b] = find(B);
if isempty(j) % B is sparse zero
    C = B;    % => return sparse zero
    if verified
        C_ = C;
    end
    return;
end

K = i+j'-1;
C = a*b.';          % If rounding is upwards, then C is a componentwise upper bound for a*b'.
if verified
    C_ = -(-a*b.');  % If rounding is upwards, then C_ is a componentwise lower bound for a*b'.
else
    C_ = [];
end

if numel(K) < 1E6
    C = sparse(K(:),1,C(:),m+n-1,1); % Entries of C(:) with same entries in K(:) are automatically summed up with respect to the actual rounding mode.
                                     % Thus, if rounding is upwards (downwards), then C is a verified componentwise upper (lower) bound for the convolution of A and B.
    %C = accumarray(K(:),C(:),[m+n-1 1],[],[],true);    
    if verified
        C_ = sparse(K(:),1,C_(:),m+n-1,1);
        %C_ = accumarray(K(:),C_(:),[m+n-1 1],[],[],true);    
    end
else                                 
    [K,I] = sort(K(:)); % The performance of "sparse()" is increased by previous sorting of the indices in K(:).   
    C = sparse(K,1,C(I),m+n-1,1); 
    %C = accumarray(K,C(I),[m+n-1 1],[],[],true);    
    if verified
        C_ = sparse(K,1,C_(I),m+n-1,1); 
        %C_ = accumarray(K,C_(I),[m+n-1 1],[],[],true);    
    end
end

end % function sconv

