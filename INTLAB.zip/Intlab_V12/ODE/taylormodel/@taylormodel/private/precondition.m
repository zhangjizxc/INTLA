function [yl,yr] = precondition(a,b,base_tm,options,Q_CL)
%PRECONDITION   preconditioning of Taylor models
%
%   [yl,yr] = precondition(a,b,base_tm)
%
% At the moment four types of preconditioning are implemented, namely QR preconditioning, parallelepiped preconditioning (PE)
% with or without blunting, curvilinear preconditioning (CL), and identity preconditioning (ID).
% (These are all types of preconditioning stated in the reference [MB2] below.)
%
%  1: QR preconditioning.       The matrix A for the linear part of "a" is decomposed by a reordered QR factorization. 
%                               The reordering is simply the ordering of the columns of A in descending order of Euclidean length.
%                               The left Taylor model gets the linear part Q, while R sticks at the right Taylor model.     
%
%  2: PE preconditioning.       The left Taylor model simply gets the linear part A of "a". If blunting is switched on, then 
%                               a blunted version of A is taken instead.
%
%  3: CL preconditioning.       The linear part for the left Taylor model gets the nearly orthogonal matrix Q of a nonverified QR decomposition 
%                               of the so-called curvilinear basis (of prescribed depth k) corresponding to the center reference trajectory.
%                               That Q is the input parameter Q_CL which was precomputed by private function "curvilinear" if curvilinear preconditioning is 
%                               switched on.
%
% -1: identity preconditioning. The left Taylor model always gets the nxn-identity matrix as linear part. This is possibly the most basic and simple kind
%                                of preconditioning. It general it is inferior to the other types above, especially for long term integration. 
%                               However, for short term integration it may give results of same quality with better performance. 
%
%   input: 
%       a:       integrated current left Taylor model
%                (Its time dependence is already eliminated by evaluating at t = t_next.)
%       b:       current right Taylor model
%       base_tm: "identity" Taylor model matrix  
%       options: global options that can be specified by the user 
%       Q_CL:    nearly orthogonal matrix for curvilinear preconditioning
%
%   output: 
%       yl: left Taylor model for the next time step
%       yr: right Taylor model for the next time step
% 
%  The implementation is based on: 
%
%  [NJN]  M. Neher, K.R. Jackson, N.S. Nedialkov, "On Taylor model based integration of ODEs", 
%           SIAM J. Numer. Anal. 45(1), pp. 236-262, 2007
%  [MB1]  Kyoko Makino and Martin Berz, "Suppression of the wrapping effect by Taylor model - based validated integrators",
%           MSU HEP Report 40910, 2003 
%  [MB2]  Kyoko Makino and Martin Berz, "Suppression of the Wrapping Effect by Taylor Model-based Verified Integrators: Long-term Stabilization by Preconditioning",
%           International Journal of Differential Equations and Applications 10(4), 105-136, 2005

% written  05/15/17     F. Buenger
% modified 09/05/19     F. Buenger  curvilinear preconditioning added
% modified 09/25/19     F. Buenger  new input parameter "options"

e = 1e-30;
if 1+e > 1      % fast check for rounding upwards
    rndold = 1;
else
    rndold = getround;
    setround(1) % rounding upwards 
end

% constants for preconditioning types
PREC_QR  = 1;  % QR preconditioning
PREC_PE  = 2;  % parallelepiped preconditioning
PREC_CL  = 3;  % curvilinear preconditioning
PREC_ID  = -1; % identity preconditioning
           
n = a(1).dim-1; % order of the underlying ODE system
if options.precondition == PREC_QR || options.precondition == PREC_PE
    A = get_linear_terms(a); % real nx(n+1)-matrix of the linear part of "a"
    A = A(:,1:n); % The (n+1)-th column of A corresponds to the linear part of the time variable
                  % which stands at the last position (n+1) for each component of "a".
                  % This column should be zero since "a" should not depend on the time variable.
                  % This final column is cut of so that A becomes an nxn-matrix.              
end

switch options.precondition 
    case PREC_QR % QR preconditioning      
        % Compute a QR decomposition of As := A*P, where P is a permutation matrix such that
        % the columns of As are sorted by Euclidean length in descending order.
        % This is step (i) of Algorithm 6.1, p. 257, [NJN], see also [MB1], Definition 12 (QR preconditioning), p.28,
        % or [MB2], Definition 16, p.113.
        
        normsA = sqrt(sum(A.*A));             % non-verified computation of the Euclidean norms of the column vectors of A
        [normsA,iA] = sort(normsA,'descend'); % The variable "normsA" is not used later on. Only the permutation iA is of interest.
    
        As = A(:,iA);      % The columns of As are sorted by Euclidean length in descending order.
        [Q,R] = qr(As);    % Compute a non-verified QR decomposition As = Q*R 
        d = sign(diag(R));
        d(d == 0) = 1;
        Q = Q.*d';         % The columns of Q are multiplied with the non-zero signs of the diagonal of R. 
                           % In other words, Q is chosen such that R has non-negative diagonal.
                           % Only the orthogonal part Q is used later on, the triangular part R is not explicitly used. 
    case PREC_PE % parallelepiped preconditioning    
        if options.blunting
            Q = blunt(A,options);
        else
            cond_bound = 1e6;   % heuristic condition number bound at which blunting is automatically used, even though it is not explicitly switched on by options.blunting = true.
                                % Feel free to change this value!
            cond_A = cond(A);
            if cond_A > cond_bound
                Q = blunt(A,options);
            else
                Q = A;                
            end
        end
        %cond_bound_max = 1e100;
        cond_bound_max = 1e16; % heuristic maximum condition number bound. If the blunted result exceeds this bound, then identity preconditioning is used instead for meaningful proceeding.   
                               % Feel free to change this value!
        if cond(Q) > cond_bound_max 
            Q = eye(n);
        end
    case PREC_CL % curvilinear preconditioning 
        Q = Q_CL;
    case PREC_ID % identity preconditioning 
        Q = eye(n); % Q := I_n is the nxn identity matrix. 
        Q_inv = Q;
end

if options.precondition ~= PREC_ID
    Q_inv = intval2iv( inv(intval(Q)) ); % Compute verified inverse of Q.
end

% All but the constant term of the integrated left Taylor model "a" is shifted to the right Taylor model. 
% Q will become the linear part of the left Taylor model and Q^{-1} is applied to the right Taylor model.
% This is step (ii) of Algorithm 6.1, [NJN].

% Additional explanations to this step: 
%   Let a0 := a - a(0) be "all but the constant term of the integrated left Taylor model", 
%   where a(0) is the constant term of the integrated left Taylor model "a". 
%   Then the intermediate setting of the right Taylor model "yr" in this step is done as follows:  
%   
%       (*)  yr = Q^{-1} * a0 o b =  (Q^{-1} * a0) o b, note that b has range in [-1,1] componentwise.
% 
%   It is numerically important(!) that the evaluation is done in the following order
%  
%       1. z  = Q^{-1} * a0
%       2. yr = z o b
%
%   The mathematically equivalent evaluation of (*) yr := Q^{-1} * (a0 o b), i.e.:
%
%       1. z  = a0 o b
%       2. yr = Q^{-1}*z
%
%   is numerically instable! If (a0 o b) is evaluated first, then the "rotational" linear part Q of a0 
%   acts on the error interval I of b which leads to wrapping. It is the main point of preconditioning 
%   to avoid this wrapping by evaluating u := (Q^{-1} * a0) first so that the (more or less) non-rotational
%   linear part R := Q^{-1}A of u will act on I causing much less wrapping.

[c,idx] = get_constant_term(a);        % c := constant terms of a, idx stores the corresponding monomial indices.
a0 = subtract_constant_term(a,idx);    % a0 := a - (constant terms of "a")

if options.shrinkwrap
    b = shrinkwrap(b,base_tm,options); % Try shrinkwrapping in order to get rid off the remainder interval.
end

yr = concatenate(Q_inv*a0,b);          % Compute yr = Q^{-1} * a0 o b =  (Q^{-1} * a0) o b , note that b has range in [-1,1] componentwise.
%yr = Q_inv*concatenate(a0,b);         %            = Q^{-1} * (a0 o b), is a mathematically equivalent but numerically instable expression, see the explanation above.
 
% Bound the range of the new right Taylor model.
% This is step (iii) of Algorithm 6.1, [NJN].
I = iv_plus(get_image(yr),get_interval(yr));
[m,s] = iv_getmidrad(I);
s_min = 1E-16; % minimum scaling constant. The value is chosen quite arbitrarily small (near zero). Feel free to change it!
               % For stability of rescaling with 1./s, each component of a scaling s is bounded from below by s_min.                    
s = max(s_min,s,'includenan'); % For stability reasons of scaling with 1./s, each component of s is bounded from below. 

% Apply a scaling matrix S^-1 to the right Taylor model such that afterwards 
% each component is contained in [-1,1] and spans [-1,1] approximately. 
% This is step (iv) of Algorithm 6.1 in [NJN].
yr = (yr-m)./s; 

% Apply the inverse scaling S to the new left Taylor model (so that scaling of left and right Taylor models cancels over all: "S*S^-1 = I").
% This is step (v) of Algorithm 6.1, [NJN].
yl = Q*(s.*base_tm + m) + c;    

if rndold ~= 1 
    setround(rndold)
end

end % function precondition
