function opt2glob(options)
%OPT2GLOB    transfer parameters from options to the global structure INTLAB_ODE_OPTIONS
%            and set all parameters which are not specified in options by default values. 
%  
%    opt2glob( options )

% written  11/06/15     F. Buenger
% modified 09/02/19     F. Buenger  new options "orders", "eps_rel", "eps_abs", "CL_depth", "CL_reffun", "blunting_factor"
% modified 02/04/20     F. Buenger  new option "taylor_expansion_method" 

global INTLAB_ODE_OPTIONS  

order_default = 12; % multivariate polynomials of degree at most 12
orders_default = []; 
sparsity_tol_default = 1E-20;
loc_err_tol_default = 1E-10;
h_min_default = 1E-4;
h0_default = 0;                 % h0 = 0 means that the initial stepsize will be chosen automatically.
bounder_default = 'NAIVE' ;     % default := 'NAIVE' : naive interval evaluation
                                % At the moment the only alternative is 'LDB' : linear dominated bounder.
shrinkwrap_default = false;     % default := false, this means that shrink wrapping is switched off.    
precondition_default = 0 ;      % default := 0, this means that preconditioning is switched off.                             
blunting_default = false;       % default := false, this means that blunting is switched off.
eps_rel_default = 1e-1;         % default = 0.1, this means 10 percent inflation  
eps_abs_default = 2e-16;        % default = 2e-16  
CL_depth_default = [];          % default for depth of curvilinear basis used for curvilinear preconditioning 
CL_reffun_default = [];         % default for depth of curvilinear basis used for curvilinear preconditioning 
blunting_factor_default = 1E-3; % default := 0.001
taylor_expansion_method_default = 'Picard'; % default is Picard iteration 

INTLAB_ODE_OPTIONS.order = verifyodeget(options,'order',order_default);   
INTLAB_ODE_OPTIONS.orders = verifyodeget(options,'orders',orders_default);   
INTLAB_ODE_OPTIONS.sparsity_tol = verifyodeget(options,'sparsity_tol',sparsity_tol_default);
INTLAB_ODE_OPTIONS.loc_err_tol = verifyodeget(options,'loc_err_tol',loc_err_tol_default);
INTLAB_ODE_OPTIONS.h_min = verifyodeget(options,'h_min',h_min_default);
INTLAB_ODE_OPTIONS.h0 = verifyodeget(options,'h0',h0_default);
INTLAB_ODE_OPTIONS.bounder = verifyodeget(options,'bounder',bounder_default); 
INTLAB_ODE_OPTIONS.shrinkwrap = verifyodeget(options,'shrinkwrap',shrinkwrap_default); 
INTLAB_ODE_OPTIONS.precondition = verifyodeget(options,'precondition',precondition_default); 
INTLAB_ODE_OPTIONS.blunting = verifyodeget(options,'blunting',blunting_default); 
INTLAB_ODE_OPTIONS.eps_rel = verifyodeget(options,'eps_rel',eps_rel_default); 
INTLAB_ODE_OPTIONS.eps_abs = verifyodeget(options,'eps_abs',eps_abs_default); 
INTLAB_ODE_OPTIONS.CL_depth = verifyodeget(options,'CL_depth',CL_depth_default); 
INTLAB_ODE_OPTIONS.CL_reffun = verifyodeget(options,'CL_reffun',CL_reffun_default); 
INTLAB_ODE_OPTIONS.blunting_factor = verifyodeget(options,'blunting_factor',blunting_factor_default); 
INTLAB_ODE_OPTIONS.taylor_expansion_method = verifyodeget(options,'taylor_expansion_method',taylor_expansion_method_default); 


if INTLAB_ODE_OPTIONS.h_min > INTLAB_ODE_OPTIONS.h0 && INTLAB_ODE_OPTIONS.h0 > 0
    error('h0 must be greater or equal h_min.')
end

% If only individual degree bounds are provided in options.orders but no overall degree bound options.order, 
% then options.order is set to the sum of the individual degree bounds.
if ~isfield(options,'order') && isfield(options,'orders') 
    INTLAB_ODE_OPTIONS.order = sum(options.orders); 
end

end % function opt2glob

