function [r,B] = BSB(a,method)
%BSB         The function computes an enclosure r of the image of the polynomial part of a Taylor model 
%            or a taylormodel-like structure using a B(ern)S(tein)B(ounder) method.
%
%   [r,B] = BSB(a,method) 
% 
% The implementation follows
%   [TG] J.Titi, J. Garloff, Matrix methods for the tensorial Bernstein form, Applied Mathematics and Computation 346, p.254-271, 2019
%
%   input argument 
%       a: Taylor model vector or matrix
%       method:  0: naive, direct method 
%                1: matrix method of Titi and Garloff [TG]  
%  
%   output arguments
%       r: image enclosures; [r.inf(i,j),r.sup(i,j)] is an enclosure of the image (of the polynomial part) of the Taylor model a(i,j).
%       B: Bernstein patch B{i,j} = {b,I,d}. 
%          If p(x) denotes the polynomial part of the Taylor model a(i,j), then  p(x) = sum_j b_{I(j,:)} * B_{I(j,:)}^(d) (x) 
%          with Bernstein basis polynomials B_i^(d) (x) = (d over i) x^i * (1-x)^(d-i), see [TG], p.256, (6)-(9).

% written  01/07/19     F. Buenger

e = 1e-30;

if 1+e > 1      % fast check for rounding upwards
    rndold = 1;
else
    rndold = getround;
    setround(1) % rounding upwards 
end

max_order = 29; % Maximum order n for which the Pascal matrix P = pascal(n) is computed exactly by MATLAB's built-in function pascal(). 

S_a = size(a);
if (length(S_a) > 2)
    error('maximally two dimensions for type taylormodel');
end

if nargin < 2 || isempty(method)
    method = 1; % Default is the matrix method of Titi and Garloff [TG]. 
end

r.inf = zeros(S_a);   % Initialize result interval (matrix).
r.sup = r.inf;
patch = nargout == 2; % Flag, that idicates, that for each Taylor model a(i,j) also the Bernstein patch  
                      % of its polynomial part shall be returned in the second output argument B.
if patch
    B = cell(S_a);
end
for i = 1:S_a(1)
    for j = 1:S_a(2)
        a_ = a(i,j);
        c = a_.coefficient;
        M = a_.monomial;      
        dim = a_.dim;
        order = a_.order;
        type = a_.type;
        
        switch method
            case 0 % direct method using INTLAB's polynom functions ptrans and bernsteincoeff (for testing only).
                cdom = iv_minus(a_.domain,a_.center);                
                a_.interval.inf = 0;                    % Set error interval to zero. We are only interested in the polynomial part of a_. 
                a_.interval.sup = 0;
                p = taylormodel2polynom(a_);
                for k = 1:dim  
                    u = cdom.inf(k);
                    v = cdom.sup(k);
                    if ~(u == 0 && v == 1)              % [u,v] ~= [0,1]
                        if type && k == dim
                            x_str = 't';
                        else
                            x_str = ['x',num2str(k)];
                        end
                        p = ptrans(p,u,v,1,0,x_str);        
                    end
                end
                [b,I,d] = bernsteincoeff_(p);
                b = intval2iv(b);
                r_.inf = min(b.inf(:),[],'includenan'); % lower bound for all Bernstein coefficients
                r_.sup = max(b.sup(:),[],'includenan'); % upper bound for all Bernstein coefficients
            case 1 % matrix method of Titi and Garloff [TG]
                if order > max_order % order exceeds maximum order for Bernstein method => trivial inclusion [-Inf,Inf]
                    r_.inf = -Inf;
                    r_.sup = Inf;
                else
                    if type == 1  % ODE-Taylor models
                        h = a_.domain.sup(dim) - a_.center(dim); % time step size h rounded upwards
                        if patch
                            [r_,b,I,d] = bernstein_coeff_1(c,M,dim,order,h);
                        else
                            r_ = bernstein_coeff_1(c,M,dim,order,h);
                        end
                    elseif type == 0 % default type
                        cdom = iv_minus(a_.domain,a_.center);
                        if patch
                            [r_,b,I,d] = bernstein_coeff_0(c,M,dim,order,cdom);
                        else
                            r_ = bernstein_coeff_0(c,M,dim,order,cdom);
                        end
                    end
                end
        end
        r.inf(i,j) = r_.inf;  % [r_.inf,r_.sup] is the enclosure of the image (of the polynomial part)
        r.sup(i,j) = r_.sup;  % of the Taylor model a_.
        if patch
            B{i,j} = {b,I,d}; % Bernstein patch of the polynomial part of the Taylor model a_.
        end
    end
end

if rndold ~= 1 
    setround(rndold)
end

end % function BSB

function [r,b,I,d] = bernstein_coeff_1(c,M,dim,order,h)
%BERNSTEIN_COEFF_1    Bernstein coefficients of multivariate polynomial p(x) = sum c(i).* x.^M(i,:) over domain [-1,1]^n x [0,h], n := dim-1. 
%                     Such multivariate polynomials come from ODE Taylor models, where h is the step size of the actual integration step.
%
%   [r,b,I,d] = bernstein_coeff_1(c,M,dim,order,h)
%
% The implementation follows
%   [TG] J. Titi, J. Garloff, Matrix methods for the tensorial Bernstein form, Applied Mathematics and Computation 346, p.254-271, 2019
%
%   input arguments 
%     c:        polynomial coefficients, floating-point numbers or intervals (iv-structures)
%     M:        monomials (exponents)
%     dim:      dimension, number of variables x_i, i = 1,...,dim
%     order:    upper bound for sum of degrees.
%     h:        cdom := [-1,1]x...x[-1,1]x[0,h] is the domain on which the polynomial p(x) is considered.  
%
%   output arguments
%     r:        enclosure of the image of the polynomial p(x) on the domain cdom, p(x) in [r.inf,r.sup], for all x in cdom = [-1,1]x...x[-1,1]x[0,h].
%     b:        Bernstein coefficients 
%     I:        indices of Bernstein coefficients
%     d:        degrees of Bernstein basis polynomials 
%
%     p(x) = sum_j b_{I(j,:)} * B_{I(j,:)}^(d) (x) with Bernstein basis polynomials B_i^(d) (x) = (d over i) x^i * (1-x)^(d-i), see [TG], p.256, (6)-(9).

% written  01/10/19     F. Buenger

persistent m P Q q D D_inv
if isempty(m) || m < order
    m = order;
    P = abs(pascal(m+1,1));  % This is [TG], p.256, Equation (2) [for l_s := m].
    D = pascal(m+1); 
    D_inv = iv_rdivide(1,D); % Pointwise inverse of D.
    J = (0:m); 
    d1 = (-2).^J';
    d2 = (-1).^J; 
    Q = d1.*P'.*d2;          % This is the matrix Q_s defined in [TG], p.260, Equation (28), for x_s := [-1,1] and order l_s := m.  
                             % Note that multiplication with powers of 2 and with +/-1 does not cause any rounding errors.                             
end

if isempty(q) || q.inf(2) ~= h || length(q.inf) < m+1    
    % Compute q := [1,h,h^2,...,h^m]. This is the diagonal of the matrix Q_s  
    % defined in [TG], p.260, Equation (28), for x_s := [0,h] and order l_s := m.      

    %J = (0:m);
    %q = iv_intpower(h,J);         
    h_ = repmat(h,1,m);
    q.sup = cumprod([1,h_]);   % Recall that rounding is upwards.                             
    q.inf = -cumprod([-1,h_]);  

% debug info:    
%     setround(-1);
%     q_inf = cumprod([1,h_]);
%     setround(1);
%     if any(q.inf ~= q_inf)
%         2
%     end
end

% Now, the coefficients of the multivariate polynomial p are arranged in a matrix A according to [TG], p.258,259, Equations (21a),(21b),(22).
l = max(M,[],1);                % l(i) is the degree (maximum exponent) for variable x_i, i = 1,...,dim
L = [1,cumprod(l(2:dim-1)+1)]'; % L = [1,l2+1,(l2+1)(l3+1),...,(l2+1)*...*(l(dim-1)+1)]
i = M(:,1)+1;                   % The exponents M(:,1) of the first variable x_1 become the row indices of the matrix A 
                                % (shift "+1" since indexing starts with 1 in MATLAB).  
                                % This is [TG], p.258, Equation (21a).
j = M(:,2:end)*L+1;             % The column indices of A are computed by "flattening out" the remaining dimensions 2,...,dim to one single dimension. 
                                % This is [TG], p.258, Equation (21b).
mA = l(1)+1; 
nA = prod(l(2:dim)+1);
if isfloat(c)  
    A = sparse(i,j,c,mA,nA);           % This is [TG], p.259, Equation (22).
else    
    A.inf = sparse(i,j,c.inf,mA,nA);   % This is [TG], p.259, Equation (22).
    A.sup = sparse(i,j,c.sup,mA,nA);   
end
    
B = A; % initialization of Bernstein patch B
for s = 1:dim-1
    l_s = l(s);                                                % degree of variable x_s
    idx = 1:l_s+1;
    P_s = P(idx,idx);                                          % See [TG], p.256, Equation (2).
    Q_s = Q(idx,idx);                                          % See [TG], p.260, Equation (28), line 1, for x_s in [-1,1].    
    
    % Compute inverses of all binomial coefficients (l_s over i), i = 0,...,l_s. 
    if l_s == 0
        d = 1;
    else
        d_.inf = D_inv.inf(idx,idx);                                   
        d_.inf = d_.inf(l_s+1:l_s:end-1); 
        d_.sup = D_inv.sup(idx,idx);                   
        d_.sup = d_.sup(l_s+1:l_s:end-1);
        d = d_;
    end    
    
    U_s = iv_mtimes_midrad(iv_times(P_s,d),Q_s);               % interval evaluation of (P_s./d)*Q_s. This is [TG], p.268, Equation (64).
    U_s.inf = sparse(U_s.inf);
    U_s.sup = sparse(U_s.sup);  
    B = iv_mtimes_midrad(U_s,B);                               % B = U_s * B                                
    B = circulate(B,l,s,dim);                                  % This is [TG], p.268, Equation (65).
end
l_n = l(dim);                                                  % degree of time variable x_dim = t
P_n = P(1:l_n+1,1:l_n+1);                                      % See [TG], p.256, Equation (2)
q_n.inf = q.inf(1:l_n+1);                                      % See [TG], p.260, Equation (28), line 2, for t = x_s in [0,h].
q_n.sup = q.sup(1:l_n+1);                                      % See [TG], p.260, Equation (28), line 2, for t = x_s in [0,h].

% Compute inverses of all binomial coefficients (l_n over i), i = 0,...,l_n.
if l_n == 0
    d = 1;
else
    idx = 1:l_n+1;
    d = D(idx,idx);                                                
    d = d(l_n+1:l_n:end-1);                                        
end
    
d = iv_rdivide(q_n,d);                                         % q_n./d
U_n = iv_times(P_n,d);                                         % interval evaluation of P_s.*(q_s./d). This is [TG], p.268, Equation (64).
U_n.inf = sparse(U_n.inf); 
U_n.sup = sparse(U_n.sup); 
B = iv_mtimes_midrad(U_n,B);                                   % B = U_n * B
[B,i,j,b] = circulate(B,l,dim,dim);                            % B is the final Bernstein patch, see [TG], p.268, Equation (65).

r.inf = min(b.inf(:),[],'includenan');                         % lower bound for all Bernstein coefficients
r.sup = max(b.sup(:),[],'includenan');                         % upper bound for all Bernstein coefficients
if length(i) < prod(l+1)
    if isempty(i)                                              % i == [] => p(x) = 0 (zero polynomial)
        r.inf = 0;                   
        r.sup = 0;
    else   
        r.inf = min(r.inf,0,'includenan');                     % If some Bernstein coefficient is 0, then it does not occur in b which is the nonzero coefficient
        r.sup = max(r.sup,0,'includenan');                     % vector of the sparse matrix B. Thus, the range r must be adapted in this case. 
    end
end

if nargout > 1                                                 % If requested, compute the multiindices I for the Bernstein coefficients b from the row and column indices i,j ... 
    I = zeros(length(i),dim);                                  % of the Bernstein patch matrix B. This is the inverse operation for the indexing given in [TG], p.258, (21a),(21b). 
    I(:,1) = i;
    for s = 2:dim
       l_s = l(s);
       I(:,s) = mod(j,l_s+1);
       j = floor(j/(l_s+1));        
    end
    d = l;                                                     % In [TG], degrees are denoted by l. Therefore, we kept this notation to have a better correspondence 
                                                               % with formulas of [TG]. But, as output argument we use "d" because "l" and "1" are too similar.     
end
end % function bernstein_coeff_1

function [r,b,I,d] = bernstein_coeff_0(c,M,dim,order,cdom)
%BERNSTEIN_COEFF_0    Bernstein coefficients of multivariate polynomial p(x) = sum c(i).* x.^M(i,:) over arbitrary domain.  
%                     Such multivariate polynomials come from Taylor models of type 0.
%
%   [r,b,I,d] = bernstein_coeff_0(c,M,dim,order,cdom)
%
% The implementation follows
%   [TG] J. Titi, J. Garloff, Matrix methods for the tensorial Bernstein form, Applied Mathematics and Computation 346, p.254-271, 2019
%
%   input arguments 
%     c:        polynomial coefficients, floating-point numbers or intervals (iv-structures)
%     M:        monomials (exponents)
%     dim:      dimension, number of variables x_i, i = 1,...,dim
%     order:    upper bound for sum of degrees.
%     cdom:     domain on which the polynomial p(x) = sum c(i).* x.^M(i,:) is considered.
%               x_i in [cdom.inf(i),cdom.sup(i)]
%
%   output arguments
%     r:        enclosure of the image of the polynomial p(x) on the domain cdom, p(x) in [r.inf,r.sup], for all x in cdom.
%     b:        Bernstein coefficients 
%     I:        indices of Bernstein coefficients
%     d:        degrees of Bernstein basis polynomials 
%
%     p(x) = sum_j b_{I(j,:)} * B_{I(j,:)}^(d) (x) with Bernstein basis polynomials B_i^(d) (x) = (d over i) x^i * (1-x)^(d-i), see [TG], p.256, (6)-(9).

% written  01/10/19     F. Buenger

persistent m P D
if isempty(m) || m < order
    m = order;
    P = abs(pascal(m+1,1)); % This is [TG], p.256, Equation (2) [for l_s := m].
    D = pascal(m+1);
end

% Now, the coefficients of the multivariate polynomial p are arranged in a matrix A according to [TG], p.258,259, Equations (21a),(21b),(22).
l = max(M,[],1);                % l(i) is the degree (maximum exponent) for variable x_i, i = 1,...,dim
L = [1,cumprod(l(2:dim-1)+1)]'; % L = [1,l2+1,(l2+1)(l3+1),...,(l2+1)*...*(l(dim-1)+1)]
i = M(:,1)+1;                   % The exponents M(:,1) of the first variable x_1 become the row indices of the matrix A 
                                % (shift "+1" since indexing starts with 1 in MATLAB).  
                                % This is [TG], p.258, Equation (21a).
if dim == 1                                
    j = ones(size(M,1),1);
else
    j = M(:,2:end)*L+1;         % The column indices of A are computed by "flattening out" the remaining dimensions 2,...,dim to one single dimension. 
                                % This is [TG], p.258, Equation (21b).
end
mA = l(1)+1; 
nA = prod(l(2:dim)+1);
if isfloat(c)                                
    A = sparse(i,j,c,mA,nA);           % This is [TG], p.259, Equation (22).
else    
    A.inf = sparse(i,j,c.inf,mA,nA);   % This is [TG], p.259, Equation (22).
    A.sup = sparse(i,j,c.sup,mA,nA);   
end
i0 = cdom.inf == 0;
u = cdom.inf;
v = cdom.sup;
w = u;
w(i0) = 1;
w = iv_rdivide(iv_minus(v,w),w);

B = A; % initialization of Bernstein patch B
for s = 1:dim
    l_s = l(s);                                      % degree of variable x_s
    P_s = P(1:l_s+1,1:l_s+1);                        % See [TG], p.256, Equation (2).
    J = (0:l_s); 
    %d = binom(l_s,0:l_s);                           % This are all binomial coefficients (l_s over i), i = 0,...,l_s, and
                                                     % 1./d is the diagonal of the matrix D_s_prime of [TG], Remark 4.2, page 261. 
    idx = 1:l_s+1;
    d = diag(flip(D(idx,idx),1))';                   % same as d = binom(l_s,0:l_s) but faster, see above.
                                                         
    if i0(s)                                         % u(s) = cdom.inf(s) == 0
        d1 = iv_intpower(v(s),J);                    % d1 = v(s).^J, see [TG], p.260, Equation (28), Line 2
        d1 = iv_rdivide(d1,d);                       % d1 = d1./d
        U_s = sparse(iv2intval(iv_times(P_s,d1)));   % U_s = P_s*D_s_prime*Q_s, see [TG], p.268, Equation (64).              
    else
        w_.inf = w.inf(s);
        w_.sup = w.sup(s);        
        d1 = iv_intpower(w_,J);                      % d1 = w_.^J,
        d1 = iv_rdivide(d1,d);                       % d1 = d1./d
        d2 = iv_intpower(u(s),J);                    % d2 = u(s).^J 
        V_s = iv_times(P_s,d1);                      % V_s = P_s*diag(d1)
        W_s = iv_times(P_s',d2);                     % W_s = P_s'*diag(d_2)
        U_s = iv_mtimes_midrad(V_s,W_s);             % U_s = P_s*D_s_prime*Q_s, see [TG], p.268, Equation (64).
        U_s.inf = sparse(U_s.inf);
        U_s.sup = sparse(U_s.sup);
    end
    B = iv_mtimes_midrad(U_s,B);                     % B = U_s * B 
    if s < dim
        B = circulate(B,l,s,dim);                    % This is [TG], p.268, Equation (65).
    else
        if dim == 1
            [i,j,b] = iv_find(B);
            i = i-1;                                 % "index - 1 = exponent"
            j = j-1;            
        else
            [B,i,j,b] = circulate(B,l,s,dim);            
        end
    end
end
r.inf = min(b.inf(:),[],'includenan');               % lower bound for all Bernstein coefficients
r.sup = max(b.sup(:),[],'includenan');               % upper bound for all Bernstein coefficients
if length(i) < prod(l+1)
    if isempty(i)                                    % i == [] => p(x) = 0 (zero polynomial)
        r.inf = 0;                   
        r.sup = 0;
    else
        r.inf = min(r.inf,0,'includenan');           % If some Bernstein coefficient is 0, then it does not occur in b which is the nonzero coefficient
        r.sup = max(r.sup,0,'includenan');           % vector of the sparse matrix B. Thus, the range r must be adapted in this case. 
    end
end
if nargout > 1                                       % If requested, compute the multiindices I for the Bernstein coefficients b from the row and column indices i,j ... 
    I = zeros(length(i),dim);                        % of the Bernstein patch matrix B. This is the inverse operation for the indexing given in [TG], p.258, (21a),(21b). 
    I(:,1) = i;
    for s = 2:dim
       l_s = l(s);
       I(:,s) = mod(j,l_s+1);
       j = floor(j/(l_s+1));        
    end
    d = l;                                           % In [TG], degrees are denoted by l. Therefore, we kept this notation to have a better correspondence 
                                                     % with formulas of [TG]. But, as output argument we use "d" because "l" and "1" are too similar.         
end 

end % function bernstein_coeff_0

function [A,row,col,v] = circulate(A,l,s,n)
% This function computes the circular (re)ordering of the matrix A for dimension s according to [TG], p.260, Lines 2,3.

% [i,j,v] = iv_find(A);

% direct, faster implementation of [i,j,v] = iv_find(A)
[i,j,v_] = find(A.inf+1i*A.sup);
v_inf = real(v_);
v_sup = imag(v_);
if nargout > 1
    v.inf = full(v_inf(:));
    v.sup = full(v_sup(:));
end

i = i-1;               % In [TG] indexing starts with 0. 
j = j-1;  

if s < n
    l_ = l(s+1);
    idx = [1:s-1,s+2:n];
else                                   
    l_ = l(1);   % There is a minor typo in [TG], p.260, Lines 2,3:
    idx = 2:n-1; % all occurences of "s+1" must be replaced by "(s mod n) + 1".
                 % For s < n this makes no difference, but in case of n = s this
                 % yields "1" instead of "n+1". Note that l(n+1) is undefined as l has length n. 
end

row = mod(j,l_+1);                         % This is [TG], p.260, Line 2.
col = floor(j/(l_+1)) + i.*prod(l(idx)+1); % This is [TG], p.260, Line 3.
mA = l_+1;
nA = numel(A.inf)/mA;
A.inf = sparse(row+1,col+1,v_inf,mA,nA);   % In MATLAB indexing starts with 1, therefore "row+1" and "col+1". 
A.sup = sparse(row+1,col+1,v_sup,mA,nA);          
end % function circulate

function [c,e,d] = bernsteincoeff_(p)
B = bernsteincoeff(p);
c = B.c;
e = B.e;
if numel(e) == 1                 % Univariate polynomials are stored as full.
    [~,e,c] = find(flip(c,2));   % Convert to sparse notation.
    e = e(:) - 1;                % exponents
    c = c(:);                    % nonzero coefficients
end
d = max(e,[],1); 

end % function bernsteincoeff_

