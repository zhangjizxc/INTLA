function display(a,name,newline)
%DISPLAY  command window display of Taylor models
%    
%   display(a,name,newline)
%
%  Single Taylor models are displayed with the following notation:
% 
%      dim   :  a.dim, number of variables of the polynomial part
%      order :  a.order, maximum degree of the polynomial part
%      type  :  a.type  0 : general Taylor model (default), 
%                       1 : ODE - Taylor model 
%
%      <iv_mid,iv_rad> : error interval a.interval in mid-/rad-notation
%      [im_inf,im_sup] : image interval a.image in infsup-notation 
%      [min,max]       : interval vector a.domain in infsup-notation 
%      center          : center point a.center of the polynomial part
%      coeff           : coefficient vector a.coefficent of the polynomial part.
%                        The corresponding monomials (exponents of variables)
%                        are displayed to the left.  
%
%  Matrices of Taylor models are displayed in a MATLAB-generic, 
%  more technical way.
%  

% written  08/27/15     F. Buenger
% modified 11/19/15     F. Buenger  display arrays of Taylor models
% modified 02/10/16     F. Buenger  "intval"-components --> intval-like structures 
% modified 11/05/18     F. Buenger  display for Octave added


global INTLAB_CONST

octave = INTLAB_CONST.OCTAVE;

if octave
    col_width = @(a) max(cellfun (@numel, a),[],1);
    disp_octave = @(a) fprintf([sprintf('%%%is',col_width(a) + 4) '\n'], eval('transpose(a){:}')); 
    uline_octave = @(a) mat2cell(repmat('-',1,sum(col_width(a))),1,col_width(a));
end

if nargin < 3 || isempty(newline)
    newline = true;
end
if nargin < 2 
    name = inputname(1);
end
if ~isempty(name)
    disp(['taylormodel ' name ' = ' ])
end
space = '  ';

if size(a,1) == 1 && size(a,2) == 1 % special display for single Taylor model    
    if newline 
        disp(' '); 
    end 
    
    % Display dimension, order, and type.
    n = a.dim;   
    [a_iv_mid,a_iv_rad] = iv_getmidrad(a.interval);   
    M = cell(1,7);
    M{1} = uint32(n);
    M{2} = uint32(a.order);
    M{3} = uint32(a.type);
    M{4} = a_iv_mid;
    M{5} = a_iv_rad;
    M{6} = a.image.inf;
    M{7} = a.image.sup;
    
    X = {'dim' 'order' 'type' 'iv_mid' 'iv_rad' 'im_inf' 'im_sup'}; 
    if octave
        T = disp2cell(M);         % Display M to string cell array.
        L = uline_octave([X;T]);  % Cretae horizontal lines under column heders.
        T = [X;L;T];              % Add column headers.
        disp_octave(T);
    else
        T = cell2table(M,'VariableNames',X); 
        disp(T);
    end
    
    % Display domains and evaluation points.
    if newline 
        disp(' '); 
    end 
    
    M = [a.domain.inf, a.domain.sup,a.center];
    if a.type == 1 % Taylor models for ODEs get variable names y1,...,ym,t, m:=n-1.
        if n == 2
            X = {'x' 't'};
        else
            X = cell(1,n);
            for i = 1:n-1
                X{i} = ['x',num2str(i)];
            end
            X{n} = 't'; % name for time variable
        end
    else % General Taylor models get variable names x1,...,xn.
        fmt = getformat;
        % Formats short and long are transformed by disp() for type table
        % to shortg and longg which does not look very nice since the decimal
        % points are not aligned. Therefore we switch to shorte and longe,
        % respectively, in these cases for displaying the domains and centers.
        switch fmt
            case {'short'}
                format 'shorte';
            case {'long'}
                format 'longe';
        end
        if n == 1
            X = {'x'};
        else
            X = cell(1,n);
            for i = 1:n
                X{i} = ['x',num2str(i)];
            end
        end
    end   
    if octave
        M = num2cell(M);
        T = disp2cell(M);                 % Display M to string cell array.
        T = [X' T];                       % Add row names.
        H = {' ' 'min' 'max' 'center'};   % column headers
        L = uline_octave([H;T]);          % Cretae horizontal lines under column heders.   
        L{1} = ' ';                       % no header above row names
        T = [H;L;T];                      % Add column headers.

        disp_octave(T);
    else
        T = array2table(M,'VariableNames',{'min' 'max' 'center'},'RowNames',X');
        disp(T);
    end
    % Display monomials and coefficients.
    if newline 
        disp(' ');
    end 
    fmt = getformat;
    % Formats short and long are transformed by disp() for type table
    % to shortg and longg which does not look very nice since the decimal 
    % points are not alligned. Therefore we switch to shorte and longe, 
    % respectively, in these cases for displaying coefficients. 
    switch fmt
        case {'short'}
            format 'shorte';
        case {'long'}
            format 'longe';
    end
    if isfield(a.coefficient,'inf') && isfield(a.coefficient,'sup')
        M = [num2cell(uint32(a.monomial)) , num2cell(a.coefficient.inf) , num2cell(a.coefficient.sup)];
        X = [X,{'coeff_inf'},{'coeff_sup'}]; % column headers
        if octave
            T = disp2cell(M);        % Display M to string cell array.
            L = uline_octave([X;T]); % Cretae horizontal lines under column heders.        
            T = [X;L;T];             % Add column headers.            
            disp_octave(T);
        else
            T = cell2table(M,'VariableNames',X);
            disp(T);
        end
    else
        M = [num2cell(uint32(a.monomial)) , num2cell(a.coefficient)];
        X = [X,{'coeff'}]; % column headers
        if octave
            T = disp2cell(M);        % Display M to string cell array.
            L = uline_octave([X;T]); % Cretae horizontal lines under column heders.        
            T = [X;L;T];             % Add column headers.            
            disp_octave(T);
        else
            T = cell2table(M,'VariableNames',X);
            disp(T);
        end
    end
    format(fmt);
       
else % generic, more technical display for non-trivial Taylor model vector/matrix
    s.type = '.';
    F = fieldnames(a);
    for i = 1:length(F)
        s.subs = F{i};
        disp([space,F{i},' : ']);
        disp(subsref_(a,s)); % a.(fname) is not wanted here.
                             % 'subsref_' already performs certain type conversions
                             % which are more suitable for displaying.
    end
end

end  % function display

function c = disp2cell(x)  
    % Each element x(i) of the array x is "displayed" to the corresponding 
    % a cell c{i} of the string cell array c.
    J = num2cell(reshape(1:numel(x),size(x)));
    f = @(x,i) strtrim(evalc(['disp(',inputname(1),'{',num2str(i),'})']));
    g = @(i) f(x,i);
    c = cellfun(g,J,'UniformOutput',false);
end
  