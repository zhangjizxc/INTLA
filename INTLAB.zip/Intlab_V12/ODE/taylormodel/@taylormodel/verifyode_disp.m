function [ts,y] = verifyode_disp(T,Y,Yr,y0,t,print,fmt)
% VERIFYODE_DISP  computes and displays the inclusions of an ODE at specified time grid points.             
%
%   res = verifyode_disp(T,Y,Yr,y0,t,print)
%                       
%   It is assumed that [T,Y,Yr] is the output of a call  
%  
%       [T,Y,Yr] = verifyode(odefun,tspan,y0,options)
%
%   for solving an ODE given by the function handle odefun
%   on a time interval tspan with interval initial value y0 
%   (type intval). 
% 
%       t: Optional parameter. If t is empty (default), then inclusions at all   
%          automatically determined time grid points T are displayed, i.e., t := T is taken.
%          If t is not empty, then inclusions and diameters at all time points t(k) are displayed.
%          Only entries of t that are contained in the integration interval [T(1),T(end)] are considered.
%          If t consists of intervals, then anly those are considered that are contained in [T(1),T(end)].
%
%   print: Optional parameter. Inclusion intervals and their diameters are 
%          displayed. Default = true;
%
%     fmt: number format, e.g. 'longe'
%       y: output argument of type intval. y(k,i) is an enclosure of y_i(ts(k)) 
%      ts: time grid points corresponding to y sorted in ascending/descending order if integration
%          was done in positive/negative direction .

% written  05/24/17     F. Buenger
% modified 05/28/18     F. Buenger  redesign, number format according to MATLAB command "format" 
% modified 08/29/18     F. Buenger  INTLAB display formats
% modified 10/17/19     F. Buenger  compute range enclosures with Bernstein bounder BSB instead of using evaltaylormodel
% modified 12/20/19     F. Buenger  evaluation at time intervals 
% modified 01/23/20     F. Buenger  handling of results comming from integration in negative direction


global INTLAB_CONST

fmt_old = getformat;
if nargin >= 7 && ~isempty(fmt)
    eval(['format ' fmt]);
end

if nargin < 6 || isempty(print) 
    print = true;
end

n = length(y0); % length of initial conditions = dimension of ODE system.
y0 = intval(y0);
K_ = length(T); % number of time grid points (for initial condition)   

direction = sign(T(end)-T(1)); % direction of integration, 1: positive direction, -1: negative direction 
                               % "direction" is distinct from zero because t0 == tf is excluded by verifyode.
T = direction * T;

if nargin < 5 || isempty(t)
    t = T;
else
    t = direction * t(:);    
    if isfloat(t)
        t = t( and(t >= T(1),t <= T(K_)) ) ;
        t = sort(t);
    else
        if isa(t,'intval')
           idx = or(t.inf < T(1),t.sup > T(K_)); % idx contains the indices of the time intervals that are not contained in the integration interval [T(1),T(end)]. 
           t(idx) = [];                          % Those intervals are discarded.
           if isempty(t)                         
               error('Error: none of the time intervals specified in t are contained in the integration interval');               
           end           
        else
            error('Error: t must be either a float or an interval (array)');
        end
    end
end

K = length(t); % number of time grid points   
y = intval(zeros(K,n)); % Initialize result y with zeros.
i_ = ''; % empty string

for k = 1:K
    tk = t(k);
    if diam(tk) == 0 % tk is a floating point number or a point interval.
        tk = inf_(tk);
        k_ = 1; % [T(k_),T(k_+1)] is the "current" time interval. 
        % Find time interval [T(k_),T(k_+1)] that contains t(k).
        % The corresponding Taylor model vector is Y(k_,:) (and also Yr(k_,:) if Yr is specified).
        while tk > T(k_+1)
            k_ = k_ + 1;
        end        
        Y_ = substitute(Y(k_,:),T(k_),tk); % Substitute the time variable in the (left) Taylor model Y(k_,:) by tk.
        if ~isempty(Yr)                    % If right Taylor models from preconditioning are provided,
            Y_ = concatenate(Y_,Yr(k_,:)); % then concatenate Y_ o Yr(k_,:).
        end        
        for i = 1:n
            if tk == T(1)
                y_ = y0(i);
            else
                y_0 = iv2intval(iv_plus(Y_(i).image,Y_(i).interval));  % Take a verified enclosure at t = t(k) directly from the Taylor model data.
                y_BSB = iv2intval(iv_plus(BSB(Y_(i)),Y_(i).interval)); % Compute another, possibly tighter verified enclosure using Bernstein polynomials.
                y_ = intersect(y_0,y_BSB);                             % Build the intersection of both enclosures.
            end
            y(k,i) = y_; % Save inclusion interval to result array.
        end
    else % tk is an interval but not a point interval.
        k1 =  find(tk.inf >= T,1,'last');  % k1 is the first index for which  T(k1) <= t_.inf holds true.
        k2 =  find(tk.sup <= T,1,'first'); % k2 is the first index for which t_.sup <= T(k2)  holds true. Thus, the interval t_ is contained in [T(k1),T(k2)].
        
        for k_ = k1:k2-1 % Note that k2 > k1 because tk = [tk.inf,tk.sup] is not a point interval.          
            t_ = infsup( max(tk.inf,T(k_)) , min(tk.sup,T(k_+1)) ); % This is the intersection of tk and [T(k_),T(k_+1)].
            Y_ = substitute(Y(k_,:),T(k_),t_); % Substitute the time variable in the (left) Taylor model Y(k_,:) by t_.
            if ~isempty(Yr)                    % If right Taylor models from preconditioning are provided,
                Y_ = concatenate(Y_,Yr(k_,:)); % then concatenate Y_ o Yr(k_,:).
            end
            for i = 1:n
                % y_ = iv2intval(evaltaylormodel(Y_(i),D)); % Evaluate Taylor model Y(k_-1,i) at time t = t(k). % This line was put in comments on 10/17/19 by F. Buenger
                y_0 = iv2intval(iv_plus(Y_(i).image,Y_(i).interval));  % Take a verified enclosure at t = t(k) directly from the Taylor model data.
                y_BSB = iv2intval(iv_plus(BSB(Y_(i)),Y_(i).interval)); % Compute another, possibly tighter verified enclosure using Bernstein polynomials.
                y_ = intersect(y_0,y_BSB);                             % Build the intersection of both enclosures.
                if k_ == k1
                    y(k,i) = y_; % Initialize enclosure of i-th component at time interval t(k).
                else
                    y(k,i) = hull(y(k,i),y_); % Build union of y(k,i) and y_.
                end
            end
        end        
    end
    
    % Display inclusions and their diameters.
    if print 
        t_str = strtrim(evalc('disp(direction*t(k))'));
        % Note that t_str might be rounded if t(k) is a floating-point number!
        % Thus, the "display version" t_str of t(k) may not
        % exactly represent the floating-point number t(k).
        % We explicitly did not(!) want to display t(k)
        % artificially as an interval in such a case.
        
        disp(['t = ',t_str]); % Display time point at which an inclusion shall be printed.
        
        for i = 1:n
            y_ = y(k,i);
            if n > 1
                i_ = ['_',num2str(i)];
            end
            switch INTLAB_CONST.INTVAL_DISPLAY
                case 'DisplayMidrad'
                    y_str = midrad(y_(:),[],[]);
                    y_str_diam = ''; % In midrad notation the diameter must not be displayed separately.
                otherwise
                    y_str = infsup(y_(:),[],[]);
                    y_str_diam = ['    d([y',i_,']) = ',num2str(diam(y_),'%.2e')];
            end
            y_str_exp = strtrim(y_str.exp);
            y_string = strtrim(y_str.str);
            if ~isempty(y_str_exp)
                y_string = [y_str_exp,' ',y_string];
            end
            % Display inclusion of component y(i) at time t(k), and also its diameter.
            disp(['    [y',i_,'] = ',y_string,y_str_diam]);
        end          
        disp(' ')
    end     
end
ts = direction * t;
eval(['format ' fmt_old]);

end  % function verifyode_disp