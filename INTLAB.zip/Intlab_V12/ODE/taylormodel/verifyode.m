function [T,Y,Yr] = verifyode(odefun,tspan,y0,options)
% VERIFYODE   verified ODE-solver for initial vaue problems  
%               
%   y'(t) = odefun(t,y(t))  with t in (tspan(1),tspan(end)) 
%   y(tspan(1)) = y0.
%
%   call:  [T,Y,Yr] = verifyode(odefun,tspan,y0,options)
%
% This verified ODE-solver is based on Taylor models.   
% The input parameters "odefun, tspan, y0, options" have the same meaning as for other (non-verified) 
% MATLAB ODE-solvers, for example, ode45. 
% 
% Input parameters:  
%
% 1) "dummy" is a dummy - Taylor model to reach the folder @taylormodel. It has no other purpose.  
%
% 2) "odefun" 
%     For a given ODE y′ = f(t,y), "odefun" is a function handle to f: R^n x [t0,tf] -> R^n. 
%     Here t is the time variable ranging between t0 := tspan(1) and tf := tspan(end), and n is the dimension of the ODE. 
%     This means f(t,y) returns the column vector of length n containing the components f(1),...,f(n). 
%     In addition, the call f(t,y,i) returns the single components f(i).
%
%     Important note: It is assumed that each component function f_i fulfills the following:
%        a) f_i consists only of arithmetic operations +,-,*,/ and of standard functions
%           like exp,log, sin, cos, tan,... ,
%           see @taylormodel for the complete list of implemented standard functions.
%        b) f_i is (m+1)-times continuously differentiable, where m is the user specified order of the 
%           used Taylor models (= maximum degree of the multivariate polynomial part).
%        c) f_i is implemented rigorously. For example, non-floating-point constants like pi
%           must be implemented by intval('pi'), see @intval/intval. 
%  
% 3) "tspan" contains the starting point and the endpoint of integration, i.e. tspan = [t0,tf].
%     (Contrary to MATLAB ode-solvers, tspan is not allowed to contain additional intermediate points.)  
%     Both t0 and tf must be floating point numbers. In particular this means that if, for example, 
%     a non-floating-point starting time t0, say t0 = 0.1, is necessary, then the ode-function odefun   
%     must be changed/rescaled by the user so that the starting time t0 is moved to a floating-point number. 
%     In general, such a rescaling is easily done. In many/most practical cases we simply have t0 = 0. 
%
%     If a previous run of verifyode shall be resumed, then tspan must(!) only contain the end time
%     of the extended time domain which must be larger than that of the previous run.
%     For example, if a previous run of verifyode performed integration from t0 = 0 to tf = 3 by calling 
%
%         [T,Y,Yr] = verifyode(odefun,[0 3],y0,options), then this run can be resumed to tf = 4 
%
%     by calling 
%
%         [T,Y,Yr] = verifyode(odefun,4,{T,Y,Yr},options) 
%
%     afterwards whereby the input arguments odefun and options must remain unchanged. 
%     For the latter call tspan = 4 only contains the new end time; the starting time t0 = 3 is determined
%     automatically from the input data {T,Y,Yr} which are the return arguments of the first call.
%     Finally, the results T,Y,Yr of the second call contain the date for the whole extended time domain [0,4].
%     
%     Integration in negative direction, i.e., t0 > tf, is supported. 
%
% 4) "y0" = (y0(1);...;y0(n)) contains the starting values. This can be a float or an interval vector.  
%     (A row vector will automatically be transformed into a column vector.)
%
%     If a previous run of verifyode shall be resumed, then y0 = {T,Y,Yr} must be a cell array containing 
%     the return arguments T,Y,Yr of that run, see the explanation for the input argument tspan. 
%
% 5) "options" contains additional parameters. Analogously to other MATLAB ode-solvers, "options"  
%     can be set by using the function verifyodeset: options = verifyodeset('name1',value1,'name2',value2,...).
%     The following parameters can be transferred (see also documentation of odeset.m) : 
%
%     - 'order'                   degree of Taylor polynomials 
%     - 'orders'                  maximum individual degrees for each variable of Taylor polynomials 
%     - 'sparsity_tol'            threshold amount for coefficients c of a multivariate polynomial 
%                                 If |c| < sparsity_tol, then the coefficient is removed from the polynomial and the (small) error 
%                                 caused by this is transferred to the error interval of the Taylor model.                        
%     - 'loc_err_tol'             tolerance for local error for step size control
%     - 'h_min'                   minimum time step size
%     - 'h0'                      initial step size. If h0 = 0, then the initial step size is computed automatically.
%     - 'shrinkwrap'              flag for "shrink wrapping", 0 = off, 1 = on 
%     - 'precondition'            Preconditioning of Taylor models, 
%                                  0 = off
%                                  1: QR preconditioning
%                                  2: parallelepiped preconditioning   
%                                  3: curvilinear preconditioning
%                                 -1: identity preconditioning
%     - 'CL_depth'                depth of curvilinear basis used for curvilinear preconditioning 
%     - 'CL_reffun'               optional function handle of a user-specified reference trajectory for curvilinear preconditioning 
%     - 'blunting'                blunting of ill-conditioned matrices during shrink wrapping or parallelepiped preconditioning, 0 = off, 1 = on 
%     - 'blunting factor'         If blunting is switched on, then the so-called blunting factors are chosen as a factor e times the matrix column lengths.   
%     - 'bounder'                 method for bounding the image of the polynomial part of a Taylor model
%                                 'NAIVE': use interval arithmetic directly (default)
%                                 'LDB'  : Linear Dominated Bounder, see the documentation of the private function "LDB" 
%                                 'BSB'  : Bernstein Bounder, see the documentation of the private function "BSB" 
%     - 'eps_rel'                 relative esilon inflation constant, see the private function "inflate" 
%     - 'eps_abs'                 absolute epsilon inflation constant, see the private function "inflate" 
%     - 'Taylor expansion method' method for non-verified computation of the Taylor series of the ODE flow, 
%                                  'Picard': Taylor expansion by Picard iteration (default)
%                                  'Lie'   : Lie derivative method, see reference [MB2].  
%                                 In our MATLAB implementatation the Lie derivative method is slower than the Picard iteration method.
%                                 However, it might be interesting for the user to see how the Lie derivative method works.
%
% Output parameters : 
%
% 1) T  : column vector of time points T = [T(1);...;T(k+1)], where [T(i),T(i+1)], i = 1,...,k  
%         are the integration intervals with T(1) = t0 and T(k+1) = tf  
% 2) Y  : solution array. Each row Y(i,:) consists of the n Taylor models Y(i,1),....,Y(i,n) that 
%         enclose the solutions y_1,...,y_n of the ODE on the time interval [T(i),T(i+1)], i = 1,...,k.
%         If preconditioning is chosen (see 4)), then the yl_j := Y(i,j), j=1,...,n, 
%         are the left (time-dependent) Taylor models.   
% 3) Yr : The corresponding (time-independent) right Taylor models are yr_j := Yr(i,j), j=1,...,n. 
%         The ODE-flow on the time interval [T(i),T(i+1)] is given by the concatenation of left and right Taylor models: 
%         yl_j(yr_1(x),...,yr_n(x),t), j=1,...,n, where x = (x_1,...,x_n) \in [-1,1]^n describes the space-like variables 
%         and t in [T(i),T(i+1)] is the time variable.                    
%        
%
% The implementation is based on: 
%  
%  [E]   I. Eble, "Über Taylor-Modelle", Dissertation at Karlsruhe Institute of Technology, 2007 (written in German),
%          Riot, C++-implementation, http://www.math.kit.edu/ianm1/~ingo.eble/de
%  [M]   K. Makino, "Rigorous analysis of nonlinear motion in particle accelerators", 
%          Dissertation at Michigan State University, 1998
%  [MB1] K. Makino and M. Berz, "Suppression of the wrapping effect by Taylor model - based validated integrators",
%          MSU HEP Report 40910, 2003 
%  [MB2] K. Makino and M. Berz, "Rigorous Integration of Flows and ODEs using Taylor Models",
%          Symbolic Numeric Computation 2009, pp. 79-84, 2009
%  [NJN] M. Neher, K.R. Jackson, N.S. Nedialkov, "On Taylor model based integration of ODEs", 
%          SIAM J. Numer. Anal. 45(1), pp. 236-262, 2007
%  [Bue] F. Buenger, "Shrink wrapping for Taylor models revisited", Numerical Algorithms 78(4), pp. 1001-1017, 2018

% written  11/04/15     F. Buenger
% modified 01/18/16     F. Buenger  record feature, see [E], Section 4.4.3.1, p.112  
% modified 05/15/17     F. Buenger  preconditioning of Taylor models   
% modified 06/29/17     F. Buenger  blunting   
% modified 07/24/17     F. Buenger  stepwise order increase in Picard iteration    
% modified 07/07/18     F. Buenger  initial stepsize h0 can be chosen automatically 
% modified 09/02/19     F. Buenger  new options "orders", "eps_rel", "eps_abs"; curvilinear preconditioning
% modified 01/15/20     F. Buenger  resuming the integration of a previous run
% modified 01/23/20     F. Buenger  integration in negative direction
% modified 02/04/20     F. Buenger  Lie derivative method added


global INTLAB_ODE_VARS

% taylormodelinit; % <-- This line moved to "startintlab.m". 
if nargin < 4
    options  = [];
end

[T,Y,Yr] = verifyodeTM(INTLAB_ODE_VARS.ZEROTAYLORMODEL,odefun,tspan,y0,options);

end % function verifyode
