function A = hankel(c,r)
%HANKEL       Hankel matrix
%
%   A = hankel(c)   or   A = hankel(c,r)
%
%The diagonal elements are always c(end). 
%

%Code is based on A.K. Booer's.
%

% written  07/27/18     S.M. Rump
%

  if isa(c,'gradient')
    sc = size(struct(c).x);
  else
    sc = size(c);
  end
  if sc(2)>1
    c = c.';
  end
  nc = prod(sc);
  if nargin==1
    r = zeros(nc,1);
    nr = nc;
  else
    if isa(r,'gradient')
      sr = size(struct(r).x);
    else
      sr = size(r);
    end
    if sr(2)>1
      r = r.';
    end
    nr = prod(sr);
  end
  
  %VVVV  x = r(2:nr,1)
  s.type = '()'; s.subs = {2:nr,1}; x = subsref(r,s);
  %AAAA  Matlab bug fix
  x = [c ; x];                            % build vector of user data
  ij = (1:nc)' + (0:(nr-1));              % Toeplitz subscripts
  %VVVV  A = x(ij)
  s.type = '()'; s.subs = {ij}; A = subsref(x,s);
  %AAAA  Matlab bug fix
  if isrow(ij) && ~isempty(A)             % preserve shape for a single row
    A = A.';
  end

end  % function hankel
