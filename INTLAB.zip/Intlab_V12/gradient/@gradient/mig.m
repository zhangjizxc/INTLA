function res = mig(A)
%MIG          Mignitude for gradients
%
%  res = mig(A)
%
%The result is a real quantity.
%

% written  04/04/14     S.M. Rump 
%

  res = mig(A.x);
  