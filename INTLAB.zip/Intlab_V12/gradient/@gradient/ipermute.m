function A = ipermute(A,order)
%IPERMUTE     Rearrange dimensions of N-D gradient array, inverse order
%
%  B = ipermute(A,order)
%
%Same functionality as Matlab's "ipermute" applied to gradient arrays.
%

% written  04/28/19     S.M. Rump 
% modified 01/14/20     S.M. Rump  numels removed
% modified 01/14/20     S.M. Rump  numel -> numels
%
  
  s = size(A.x);
  inverseorder(order) = 1:numels(order);   % Inverse permutation order
  index = permute(reshape(1:prod(s),s),inverseorder);
  A.x = permute(A.x,inverseorder);
  A.dx = A.dx(index(:),:);
  
end  % function ipermute
  