function disp(x)
%DISP         Display function for pop-up windows in debugger
%

% written  04/26/13     S.M. Rump
% modified 10/17/16     S.M. Rump  restricted output for popup windows
% modified 01/14/20     S.M. Rump  numels removed
% modified 01/14/20     S.M. Rump  numel -> numels
%

  global INTLAB_CONST
  
  if numels(x)<INTLAB_CONST.DISPLAY_POPUP
    display(x);
  else
    disp('Display suppressed.')
  end
  
end  % function disp
  