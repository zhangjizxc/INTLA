function res = ismatrix(a)
%ISMATRIX       returns 1 if a is matrix (nxk matrix)
%
%   res = ismatrix(a)
%

% written  07/27/17  S.M. Rump
%

  res = ismatrix(struct(a).x);
  