function res = isrow(a)
%ISROW          returns 1 if a is row vector (1xk matrix)
%
%   res = isrow(a)
%

% written  07/27/17  S.M. Rump
%

  res = isrow(struct(a).x);
  