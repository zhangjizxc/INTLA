function res = isvector(a)
%ISVECTOR       returns 1 if a is vector (1xk or kx1 matrix)
%
%   res = isvector(a)
%

% written  07/27/17  S.M. Rump
%

  res = isvector(struct(a).x);
  