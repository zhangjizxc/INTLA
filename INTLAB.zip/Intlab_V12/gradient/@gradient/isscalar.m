function res = isscalar(a)
%ISSCALAR       returns 1 if a is scalar (1x1 matrix)
%
%   res = isscalar(a)
%

% written  07/27/17  S.M. Rump
%

  res = isscalar(struct(a).x);
  