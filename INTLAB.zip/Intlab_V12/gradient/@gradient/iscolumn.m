function res = iscolumn(a)
%ISCOLUMN       returns 1 if a is column vector (kx1 matrix)
%
%   res = iscolumn(a)
%

% written  07/27/17  S.M. Rump
%

  res = iscolumn(struct(a).x);
  