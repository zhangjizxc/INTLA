function A = circulant(r)
%CIRCULANT    Circulant matrix
%
%   A = circulant(r)
%
%Circulant matrix with first row r. 
%

% written  07/27/18     S.M. Rump
%

  %VVVV  c = r([1 length(r.x):-1:2])
  s.type = '()'; s.subs = {[1 length(r):-1:2]}; c = subsref(r,s);
  %AAAA  Matlab bug fix
  A = toeplitz(c,r);

end  % function circulant
