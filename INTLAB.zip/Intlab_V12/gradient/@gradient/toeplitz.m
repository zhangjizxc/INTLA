function A = toeplitz(c,r)
%TOEPLITZ     Toeplitz matrix
%
%   A = toeplitz(c)   or   A = toeplitz(c,r)
%
%The diagonal elements are always c(1). 
%
%In case of one input parameter, the symmetric (nor Hermitian) Toeplitz
%matrix toeplitz(c,c') will be created. 
%

%Code is based on A.K. Booer.
%

% written  07/27/18     S.M. Rump
%

  if isa(c,'gradient')
    sc = size(struct(c).x);
  else
    sc = size(c);
  end
  if sc(2)>1
    c = c.';
  end
  nc = prod(sc);
  if nargin==1
    r = c;
    nr = nc;
  else
    if isa(r,'gradient')
      sr = size(struct(r).x);
    else
      sr = size(r);
    end
    if sr(2)>1
      r = r.';
    end
    nr = prod(sr);
  end
  
  %VVVV  x = r(nr:-1:2,1)
  s.type = '()'; s.subs = {nr:-1:2,1}; x = subsref(r,s);
  %AAAA  Matlab bug fix
  x = [x ; c];                            % build vector of user data
  ij = (0:nc-1)' + (nr:-1:1);             % Toeplitz subscripts
  %VVVV  A = x(ij)
  s.type = '()'; s.subs = {ij}; A = subsref(x,s);
  %AAAA  Matlab bug fix
  if isrow(ij) && ~isempty(A)             % preserve shape for a single row
    A = A.';
  end

end  % function toeplitz
