%Help file for INTLAB Version 9
%
% - INTLAB is now working under Octave
% - various corrections and improvements, in particular taking care of Matlab and Octave bugs
%
% New demo functions: 
%  verifyfft         Verified forward and backwart FFT
%
