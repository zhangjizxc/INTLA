function dydt = quadratic_problem(t,y,i)
%QUADRATIC     ODE-function for u'' = u^2

% written  02/06/20     F. Buenger

if nargin == 2 || isempty(i)
    dydt = [y(2);sqr(y(1))];
else
   switch i
       case 1
           dydt = y(2);
       case 2    
           dydt = sqr(y(1));
   end
end

end % function quadratic_problem

