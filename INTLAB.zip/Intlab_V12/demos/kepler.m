function dydt = kepler(t,y,i)
% KEPLER     ODE-function for asteroid motion

% written  02/08/20     F. Buenger

persistent g_
if isempty(g_)
    g_ = intval(-9986)/1E4;                % verified inclusion of -0.9986
end
if nargin == 2 || isempty(i) || i >= 4
    if isfloat(y)                          % non-verified branch for MATLAB's non-verified ODE-solvers like ode45
        g = -0.9986;
    else                                   % verified branch for verifyode
        g = g_;
    end
    d = sqr(y(1)) + sqr(y(2)) + sqr(y(3));
    z = (d.^-1.5).*g;                      % Note that 1.5 is a floating-point number.
end
if nargin == 2 || isempty(i)
    dydt = [y(4:6);y(1:3).*z];
else
    if i <= 3
        dydt = y(i+3);
    else
        dydt = y(i-3).*z;
    end
end
end % function kepler
